<?php

error_reporting(1);
global $base_url;
include('dbcon.php');
global $redirect;
global $user;
$user_id = $user->uid;

$redirect_path = $base_url . '/' . $redirect;

$project_id = sget($_REQUEST, 'id');

// Get Like details of the project with login user
$like_result = mysql_query ("SELECT * 
							 FROM  `like_company` 
							 WHERE  project_id = '".$project_id."' and user_id = '".$user_id."'");
$likeabout = mysql_num_rows($like_result);

// Get Project details from -  'maenna_company' table
$pro_sql = "select * from maenna_company where companyid = %d";
$pro_result = db_query($pro_sql, array($project_id));
$pro_Row = db_fetch_object($pro_result);


// Get Project details from -  'maenna_about' table
$sql = "select * from maenna_about where project_id = %d";
$result = db_query($sql, array($project_id));
$Row = db_fetch_object($result);

$path = './themes/maennaco/images/project/';
$option = sget($_REQUEST, 'view');
$field = sget($_REQUEST, 'field');
$param_val = sget($_REQUEST, 'param');

if($option == 'delete')
{
	$sql = "UPDATE maenna_about SET $param_val = '' where project_id = %d";
	$result = db_query($sql, array($project_id));
	header( 'Location: ' . $redirect_path ) ;
}
if($option == 'edit')
{
	switch($field)
	{
		case 'project' :
						
						if(!empty($_FILES))
						{
							$file_name = "";
							$allowedExts = array("jpg", "jpeg", "gif", "png");
							$extension = end(explode(".", $_FILES["project"]["name"]));
							if ((($_FILES["project"]["type"] == "image/gif")
							|| ($_FILES["project"]["type"] == "image/jpeg")
							|| ($_FILES["project"]["type"] == "image/png")
							|| ($_FILES["project"]["type"] == "image/pjpeg"))
							&& ($_FILES["project"]["size"] < 2048000)
							&& in_array($extension, $allowedExts))
							  {
							  if ($_FILES["project"]["error"] > 0)
							    {
							    echo "Return Code: " . $_FILES["project"]["error"] . "<br>";
							    }
							  else
							    {
							      $new_file_name = $_FILES["project"]["name"];
								  if (file_exists($path . $_FILES["project"]["name"]))
							      {
							      //echo $_FILES["project"]["name"] . " already exists. ";
								  $new_file_name = time() . $_FILES["project"]["name"];
							      }
							    
							      move_uploaded_file($_FILES["project"]["tmp_name"],
							      $path . $new_file_name);
								  $file_name = $new_file_name;
							      //echo "Stored in: " . "upload/" . $_FILES["project"]["name"];
							      
							    }
							  }
							else
							  {
							  echo "Please Upload speicfied images with size lessthan 2MB";
							  }
							
							if(!empty($file_name))
							{
								if(empty($Row))
								{
									$sql = "INSERT INTO maenna_about(project_id, project) VALUES(%d, '" . checkValues($file_name) . "') ";
									$result = db_query($sql, array($project_id));
								}
								else
								{
									$sql = "UPDATE maenna_about SET project = '" . checkValues($file_name) . "' where project_id = %d";
									$result = db_query($sql, array($project_id));
								}
								header( 'Location: ' . $redirect_path ) ;
							}
							else
							{
								maenna_project($Row, $path);
							}
						}
						else
						{
							maenna_project($Row, $path);
						}
						break;
		case 'mission' :
						if(!empty($_POST))
						{
							if(empty($Row))
							{
								$sql = "INSERT INTO maenna_about(project_id, mission) VALUES(%d, '" . checkValues($_POST['mission']) . "') ";
								$result = db_query($sql, array($project_id));
							}
							else
							{
								$sql = "UPDATE maenna_about SET mission = '" . checkValues($_POST['mission']) . "' where project_id = %d";
								$result = db_query($sql, array($project_id));
							}
							header( 'Location: ' . $redirect_path ) ;
						}
						else
						{
							maenna_mission($Row);
						}
						
						break;
		case 'goal' :
						if(!empty($_POST))
						{
							if(empty($Row))
							{
								$sql = "INSERT INTO maenna_about(project_id, goal) VALUES(%d, '" . checkValues($_POST['goal']) . "') ";
								$result = db_query($sql, array($project_id));
							}
							else
							{
								$sql = "UPDATE maenna_about SET goal = '" . checkValues($_POST['goal']) . "' where project_id = %d";
								$result = db_query($sql, array($project_id));
							}
							header( 'Location: ' . $redirect_path ) ;
						}
						else
						{
							maenna_goal($Row);
						}
						break;
		case 'founded' :
						if(!empty($_POST))
						{
							if(empty($Row))
							{
								$sql = "INSERT INTO maenna_about(project_id, founded) VALUES(%d, '" . checkValues($_POST['founded']) . "') ";
								$result = db_query($sql, array($project_id));
							}
							else
							{
								$sql = "UPDATE maenna_about SET founded = '" . checkValues($_POST['founded']) . "' where project_id = %d";
								$result = db_query($sql, array($project_id));
							}
							header( 'Location: ' . $redirect_path ) ;
						}
						else
						{
							maenna_founded($Row);
						}
						break;
		case 'industry' :
						if(!empty($_POST))
						{
							if(empty($Row))
							{
								$sql = "INSERT INTO maenna_about(project_id, industry) VALUES(%d, '" . checkValues($_POST['industry']) . "') ";
								$result = db_query($sql, array($project_id));
							}
							else
							{
								$sql = "UPDATE maenna_about SET industry = '" . checkValues($_POST['industry']) . "' where project_id = %d";
								$result = db_query($sql, array($project_id));
							}
							header( 'Location: ' . $redirect_path ) ;
						}
						else
						{
							maenna_industry($Row);
						}
						break;
		case 'links' :
						break;				
	}
}
else
{
?>
<div class="abt">
        <?php

    if ($AccessObj->user_type == 'super' || $AccessObj->uid == sget($_REQUEST,'id')) { ?>
	<div class="abtitle" style="border:none;"><?php echo $pro_Row->projname?> <div class='abtbtn'><a href="<?php echo $redirect_path;?>&view=edit&field=project">Edit</a></div></div>

        <?php } ?>
        <div style="clear:both"></div>
    
	<div class="abt-content">	
		<?php 
			if(!empty($Row->project) && file_exists($path . $Row->project))
			{
				echo "<img src='" .$path . $Row->project ."' style='width:600px; height:210px;'/>";
			}
			else
			{
				echo "<div class='abtadd'><span>ADD A PHOTO THAT <br/> TELLS YOUR COMPANY'S STORY</span></div>";
			}
		?>
		
	</div>
</div>

<div class='abtloop'>
<div class='abt-title'><?php if(empty($Row->mission)) echo "MISSION" ;?></div>
    <?php

    if ($AccessObj->user_type == 'super' || $AccessObj->uid == sget($_REQUEST,'id')) { ?>

        <div class="abtbtn"><a href=<?php echo $redirect_path;?>&view=edit&field=mission' class='tool' >EDIT</a></div>
        <?php } ?>
        <div style="clear:both"></div>
<div>
<p <?php if(!empty($Row->mission)) echo "style='font-size: 16px;'"; ?>>
<?php
if(!empty($Row->mission))
	{
		echo $Row->mission;
	}
	else
	{
		echo "Write Your Company's mission ";
	}
?></p>
</div>
</div>

<div class='abtloop'>
            
<div class='abt-title'><?php if(empty($Row->goal)) echo "YEAR GOAL" ; ?></div>
    <?php

    if ($AccessObj->user_type == 'super' || $AccessObj->uid == sget($_REQUEST,'id')) { ?>
<div class="abtbtn"><a href='<?php echo $redirect_path;?>&view=edit&field=goal' class='tool' >EDIT</a></div>
    <?php } ?>
        <div style="clear:both"></div>
<div>
<p <?php if(!empty($Row->goal)) echo "style='font-size: 16px;'"; ?>>
<?php
if(!empty($Row->goal))
	{
		echo $Row->goal;
	}
	else
	{
		echo "Describe what you care to complete this year";
	}
?>
</p>
</div>
</div>

<div class='abtloop'>
<div class='abt-title'>FOUNDED 
<span>
<?php
if(!empty($Row->founded))
	{
		echo $Row->founded;
	}
	else
	{
		echo " - ";
	}
?>
</span>
</div>
    <?php

    if ($AccessObj->user_type == 'super' || $AccessObj->uid == sget($_REQUEST,'id')) { ?>
<div class="abtbtn"><a href='<?php echo $redirect_path;?>&view=edit&field=founded' class='tool' >EDIT</a></div>

    <?php } ?>

    <div style="clear:both"></div>
</div>

<div class='abtloop'>
<div class='abt-title'>INDUSTRY 
<span>
<?php
if(!empty($Row->industry))
	{
		$industry_values = industry_values();
		
	    foreach($industry_values as $key => $array)
	    {
	        foreach($array as $kkey=> $val)
	        {            
	            if(($Row->industry == $kkey) )
					echo $val;            
	        }       
		}		
	}
	else
	{
		echo " - ";
	}
?>
</span>
</div>
    <?php

    if ($AccessObj->user_type == 'super' || $AccessObj->uid == sget($_REQUEST,'id')) { ?>
<div class="abtbtn"><a href='<?php echo $redirect_path;?>&view=edit&field=industry' class='tool' >EDIT</a></div>
    <?php } ?>


    <div style="clear:both"></div>
</div>


<div class="abtloop">
<div class="abt-title"></div>
<div align='center'>
	<?php
		if($likeabout == 1) {
	?>
	<span id="like_company_id" ><a class="ablike" onclick="like_company('unlike', '<?=$project_id?>','<?=$user_id?>');">Unlike</a></span>
	<?php } else {?>
	<span id="like_company_id"><a class="ablike"  onclick="like_company('like', '<?=$project_id?>','<?=$user_id?>');">Like</a></span>
	<?php } ?>

	<!-- <a href="#" class="ablike" style="border:none;">Like</a> -->
<?php

    $coll_status = collaboratorStatus($user_id, $project_id);
    if ( $coll_status == 'pending') $value = "<a style='cursor:pointer;' title='Uncontribute' type='uncontribute' cid = '".$project_id."' uid = '".$user_id."' class='contribute' >Pending</a>";

    elseif ($coll_status == 'confirmed') $value = "<a style='cursor:pointer;' title='UNCONTRIBUTE' type='uncontribute' cid = '".$project_id."' uid = '".$user_id."' class='contribute' >Contributing</a>";

    // elseif ($coll_status == 'declined') $value = "<div title='Full' style=' margin-top:5px;margin-right:10px; color:#2fa600;'>FULL</div>";

    elseif ($coll_status == 'declined') $value = "<a style='cursor:pointer;' title='FULL' class='contribute' >Contributing</a>";

    elseif ($user_id != $project_id) {

        if (!$canCollaborate) {

            $value =  "<a title='Contribute' type='no_coll'  style=' cursor:pointer;'>Contribute</a>";

        }

        else $value = "<a style='cursor:pointer;' type='contribute' cid = '".$project_id."' uid = '".$user_id."' class='contribute' >Contribute</a>";
    }

    echo $value;
    ?>

</div>
<div style="clear:both"></div>

</div>
<script type="text/javascript" src="/themes/maennaco/jui/comments/js/jquery.livequery.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        init_contribute();
    });
</script>
<?php 
}

function maenna_project($Row = '', $path = '')
{
	$param = '"project"';	
	if(!empty($Row->project) && file_exists($path . $Row->project))
	{
		$image = "<img src='" .$path . $Row->project ."' style='max-width:200px;'/>";
		$delete = "<input type='button' value='Delete' onclick='delete_record($param);' class='button'>";
	}
	else
	{
		$image = "";
	}
	
	
	$content .= "<div class='act-content'>";
            
	$content .= "<form method='post' action='' enctype='multipart/form-data' onsubmit='return valid_form($param);' >
					<div class='content_box'><div class='box_title shaded_title'>Edit Project</div></div>
					<div class='entry'>
						<div class='entry-content'>
							<input type='file' name='project' id='project'/><br />
							Please upload jpg/png/gif images of size lessthan 2MB
						</div>
						$image
					</div><br />
					<div align='center'>			
						<input type='submit' value='Submit' class='button'>
						$delete
						<input type='button' value='Cancel' onclick='redirect();' class='button'>
					</div>
				</form>";
	$content .= "</div>";
	echo $content;
}

function maenna_mission($Row = '')
{
	$param = '"mission"';
	if(!empty($Row->mission))
	{
		$delete = "<input type='button' value='Delete' onclick='delete_record($param);' class='button'>";
	}
	
	$content .= "<div class='act-content'>";
            
	$content .= "<form method='post' action='' enctype='mutipart/form-data' onsubmit='return valid_form($param);'>
					<div class='content_box'><div class='box_title shaded_title'>Edit Mission</div></div>
					<div class='entry'><div class='entry-content'><textarea name='mission' id='mission' style='width: 99%;'>$Row->mission</textarea></div></div>
					<div align='center'>
						<input type='submit' value='Submit' class='button'>
						$delete
						<input type='button' value='Cancel' onclick='redirect();' class='button'>
					</div>
				</form>";
	$content .= "</div>";
	echo $content;
}

function maenna_goal($Row = '')
{
	$param = '"goal"';
	if(!empty($Row->goal))
	{
		$delete = "<input type='button' value='Delete' onclick='delete_record($param);' class='button'>";
	}
	$content .= "<div class='act-content'>";
            
	$content .= "<form method='post' action='' enctype='mutipart/form-data' onsubmit='return valid_form($param);'>
					<div class='content_box'><div class='box_title shaded_title'>Edit Goal</div></div>
					<div class='entry'><div class='entry-content'><textarea name='goal' id='goal' style='width: 99%;'>$Row->goal</textarea></div></div>
					<div align='center'>		
						<input type='submit' value='Submit' class='button'>
						$delete
						<input type='button' value='Cancel' onclick='redirect();' class='button'>
					</div>		
				</form>";
	$content .= "</div>";
	echo $content;
}

function maenna_founded($Row = '')
{
	$param = '"founded"';
	if(!empty($Row->founded))
	{
		$delete = "<input type='button' value='Delete' onclick='delete_record($param);' class='button'>";
	}
	
	$content .= "<div class='act-content'>";
            
	$content .= "<form method='post' action='' enctype='mutipart/form-data' onsubmit='return valid_form($param);'>
					<div class='content_box'><div class='box_title shaded_title'>Edit Founded</div></div>
					<div class='entry'><div class='entry-content'>	
						<input type='text' name='founded' id='founded' value='$Row->founded' />
					</div></div><br />						
					<div>
						<input type='submit' value='Submit' class='button'>
						$delete
						<input type='button' value='Cancel' onclick='redirect();' class='button'>
					</div>
				</form>";
	$content .= "</div>";
	echo $content;
}

function maenna_industry($Row = '')
{
	$param = '"industry"';
	$test = industry_options($Row->industry);
	$select =  "<select name='industry' id='industry'>" . $test . "</select>";
	if(!empty($Row->industry))
	{
		$delete = "<input type='button' value='Delete' onclick='delete_record($param);' class='button'>";
	}
	
	$content .= "<div class='act-content'>";
            
	$content .= "<form method='post' action='' enctype='mutipart/form-data' onsubmit='return valid_form($param);'>
					<div class='content_box'><div class='box_title shaded_title'>Edit Industry</div></div>
					<div class='entry'><div class='entry-content'>
						$select
					</div></div><br />							
					<div>
						<input type='submit' value='Submit' class='button'>
						$delete
						<input type='button' value='Cancel' onclick='redirect();' class='button'>
					</div>
				</form>";
	$content .= "</div>";
	echo $content;
}

function checkValues($value)
 {
   // Use this function on all those values where you want to check for both sql injection and cross site scripting
   //Trim the value
   $value = trim($value);
   
  // Stripslashes
  if (get_magic_quotes_gpc()) {
   $value = stripslashes($value);
  }
  
   // Convert all &lt;, &gt; etc. to normal html and then strip these
   $value = strtr($value,array_flip(get_html_translation_table(HTML_ENTITIES)));
  
   // Strip HTML Tags
   $value = strip_tags($value);
  
  // Quote the value
  $value = mysql_real_escape_string($value);
  $value = htmlspecialchars ($value);
  return $value;
  
 }
 function industry_values()
{
    $Data =  array( "Basic Materials" => array(
                        'Agriculture',
                        'Building Materials',
                        'Chemicals',
                        'Coal',
                        'Forest Products',
                        'Metals & Mining',
                        'Steel',
                                              ),
                   "Consumer Cyclical" => array(
                        'Advertising & Marketing Svcs',
                        'Autos',
                        'Entertainment',
                        'Homebuilding & Construction',
                        'Manuf. - Apparel & Furniture',
                        'Packaging & Containers',
                        'Personal Services',
                        'Publishing',
                        'Restaurants',
                        'Retail - Apparel & Specialty',
                        'Travel & Leisure',
                   ),
                   "Consumer Defensive" => array(
                        'Beverages - Alcoholic',
                        'Beverages - Non-Alcoholic',
                        'Consumer Packaged Goods',
                        'Education',
                        'Retail - Defensive',
                        'Tobacco Products',
                               ),
                   "Financial Services" => array(
                        'Asset Management',
                        'Banks',
                        'Brokers & Exchanges',
                        'Credit Services',
                        'Insurance',
                        'Insurance - Life',
                        'Insurance - Property & Casualty',
                        'Insurance - Specialty',
                               ),
                   "Real Estate" => array(
                        'Real Estate Services',
                        'REITs',
                                          ),
                   "Healthcare" => array(
                        'Biotechnology',
                        'Drug Manufacturers',
                        'Health Care Plans',
                        'Health Care Providers',
                        'Medical Devices',
                        'Medical Diagnostics & Research',
                        'Medical Distribution',
                        'Medical Instruments & Equipment',
                        'Utilities - Independent Power Producers',
                        'Utilities - Regulated',
                        'Communication Services',
                                         ),
                   "Energy" => array(
                        'Oil & Gas - Drilling',
                        'Oil & Gas - E&P',
                        'Oil & Gas - Integrated',
                        'Oil & Gas - Midstream',
                        'Oil & Gas - Refining & Marketing',
                        'Oil & Gas - Services',
                                     ),
                   "Industrial"  => array(
                        'Aerospace & Defense',
                        'Airlines',
                        'Business Services',
                        'Conglomerates',
                        'Consulting & Outsourcing',
                        'Employment Services',
                        'Engineering & Construction',
                        'Farm & Construction Machinery',
                        'Industrial Distribution',
                        'Industrial Products',
                        'Transportation & Logistics',
                        'Truck Manufacturing',
                        'Waste Management',
                                          ),
                   "Technology" => array(
                        'Application Software',
                        'Communication Equipment',
                        'Computer Hardware',
                        'Online Media',
                        'Semiconductors',
                   )
                   
                   );
    $Output = array();
    foreach($Data as $categoryTitle => $CategoryArray)
    {
        $M = array();
        foreach($CategoryArray as $val)
        {
            $mKey = preg_replace('/[^a-z0-9]/i','',$val);
            $M["$mKey"] = $val;
        }
        $Output["$categoryTitle"] = $M;
        
    }
	//echo "Values<pre>" ;print_r($Output); echo "</pre>";
    return $Output;
}

function industry_options($selected = null)
{ 
    $industry_options = '';
    $industry_values = industry_values();
    foreach($industry_values as $key => $array)
    {
        $industry_options .= "<optgroup label='$key'>";
        foreach($array as $kkey=> $val)
        { 
            $sel = '';
            if(($selected == $kkey) && (! empty($selected)))$sel = 'selected';
            $industry_options .= "<option value='$kkey' $sel>$val</option>";
        }
        $industry_options .= "</optgroup>";
	}
    return $industry_options;
}
?>
<script>
function redirect()
{
	window.location.href='<?php echo $redirect_path;?>';
}

function delete_record(param)
{
	if(confirm('Continue to remove record'))
	{
		window.location.href='<?php echo $redirect_path;?>&view=delete&param='+param;
	}
	else
	{
		return false
	}
}

function valid_form_testing(field_id)
{ 
	var field = '';
	field = document.getElementById(field_id).value;
	if(field == '')
	{
		alert('Please fill the field values and submit');
		return false;
	}
	else
	{
		return true;
	}
}
function like_company(type, project_id, user_id)
{	
	if(type == 'like')
		var status = 1;
	else
		var status = 0;
	
	$.ajax({
			type: 'get',
			url: '<?php echo $base_url; ?>/themes/maennaco/includes/delete.php?type=like_company&project_id='+project_id+'&user_id='+user_id+'&status='+status,
			data: '',
			beforeSend: function(){	},
			success: function(){
						if(type == 'like')
						{
							$('#like_company_id').html("<a class='ablike' style='cursor:pointer;border:none;' onclick='like_company(\"unlike\", "+project_id+","+user_id+");'>Unlike</a>");
						}
						else
						{
							$('#like_company_id').html("<a class='ablike' style='cursor:pointer;border:none;' onclick='like_company(\"like\", "+project_id+","+user_id+");'>Like</a>");
						}			
					}
		});
}
</script>
