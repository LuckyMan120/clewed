<?php

chdir('../../../');
require_once './includes/bootstrap.inc';
drupal_bootstrap(DRUPAL_BOOTSTRAP_FULL);

$return = menu_execute_active_handler();

if (is_int($return)) {
    switch ($return) {
        case MENU_NOT_FOUND:
            drupal_not_found();
            break;
        case MENU_ACCESS_DENIED:
            drupal_access_denied();
            break;
        case MENU_SITE_OFFLINE:
            drupal_site_offline();
            break;
    }
}
	
	if (md5($_REQUEST['c_id'].$_REQUEST['u']."kyarata75") === $_REQUEST['m'])
	{
	
	mysql_query("delete from wall_posts_comments where c_id ='".$_REQUEST['c_id']."' AND user ='".$_REQUEST['u']."'");
	}
?>