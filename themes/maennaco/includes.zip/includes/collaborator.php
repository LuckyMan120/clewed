<?php

	include('dbcon.php');

	if ($_REQUEST['type'] == 'setPublic') {

						if ($_REQUEST['target_publicity'] == 'public') $status = 1; else $status = 0;
						mysql_query("UPDATE maenna_company SET public = ".$status." WHERE companyid = '".$_REQUEST['cid']."' ") or die(mysql_error());
					


					}

        elseif ($_REQUEST['type'] == 'cnfColl') {
    
                
	 	function getDisplayName($id)
		  {
		      if(empty($id)) return 'invalid id';
		      $sql = "select users_roles.*, maenna_people.firstname from users_roles, maenna_people where users_roles.uid = '".$id."' and maenna_people.pid = '".$id."' limit 1";
		      $result1 = mysql_query($sql);
		      $Row = mysql_fetch_assoc($result1);
		      if(empty($Row)) return "invalid user role setting - $id";
		      $rid = $Row['rid'];
		      $firstname = strtoupper($Row['firstname']);
		      if(in_array($rid, array(6, 10))){
			  $output = "${firstname}MAEADM" . sprintf("%05s", $id +100);
		      }else{
			  $output = "${firstname}MAE" . sprintf("%04s", $id +100);
		      }
                      
                      $sql = mysql_query("SELECT name FROM role WHERE rid = $rid") or die(mysql_error());
                      $Row = mysql_fetch_assoc($sql);
                      $output.=", ".strtoupper($Row['name']);
                      
		      return $output;
		  }

		mysql_query("UPDATE maenna_collaborators SET status = '".$_REQUEST['status']."' WHERE uid = '".$_REQUEST[pid]."' AND cid = '".$_REQUEST[companyId]."' ") or die(mysql_error());

		//Get user gender
		$q1 = mysql_query("SELECT gender FROM maenna_people WHERE pid = $_REQUEST[pid]");
		$gender_tmp = mysql_fetch_array($q1);
		$gender = $gender_tmp['gender'];
		 //Check if user have a profile picture
		  if (file_exists('sites/default/images/profiles/50x50/'.$value.'.jpg')) { $avatar = 'sites/default/images/profiles/50x50/'.$_REQUEST['pid'].'.jpg';} 
		  else {
				if ($gender == 'm' || $gender == '') { $avatar =' /themes/maennaco/images/prof-avatar-male.png';}

					else $avatar = '/themes/maennaco/images/prof-avatar-female.png';
			}
                $pro_maeid = getDisplayName($_REQUEST['pid']);
                $box_content = "\n<div style=\"height:55px;\" class='row singlerow'><img src=".$avatar." style=\"float:left;               margin-right:5px; width:50px; height:50px;\">
                 <p style=\" font-size:11px; color:#666; font-family:Helvetica; text-transform:uppercase;margin-top:20px;\">$pro_maeid</p></div>";

	die($box_content);

	}
	elseif ($_REQUEST['type'] == 'uncollaborate') {

	mysql_query("DELETE FROM maenna_collaborators WHERE uid = '".$_REQUEST['pid']."' AND  cid = '".$_REQUEST['companyId']."' ") or die(mysql_error());

	echo "Uncollaboration succeeded";

	}

	else {

	mysql_query("INSERT INTO maenna_collaborators (uid,cid,status) VALUES ('".$_REQUEST['pid']."','".$_REQUEST['companyId']."','pending') ") or die(mysql_error());

	echo "Your request has been succesfully sent";

	}

	
?>