<?php
error_reporting(0);
global $base_url;
include('dbcon.php');

$user_id = $_GET['user_id'];
$url = $base_url . "/account?tab=professionals&page=pro_detail&id=" . $user_id . "&section=pro_industry_view&type=discussion&sortdate=";
// Get Schedule dates from -  'maenna_professional' table
$sql = "select distinct datetime from maenna_professional WHERE postedby = " . $user_id;
$result = mysql_query($sql);

while($Row = mysql_fetch_array($result))
{
	$date = date('Y-m-d',$Row['datetime']);	
	$day = date('d',$Row['datetime']);	
	if( ! in_array($date, $backup_array))
	{
		$array[] = array('id' => "",
						'title' => "",		  
						'start' => $date,
						'url' => $url . $Row['datetime'],
						'day'=>$day);
	}
	$backup_array[] = $date;
}

echo json_encode($array);
?>
