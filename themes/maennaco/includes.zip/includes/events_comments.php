<script type="text/javascript" src="/themes/maennaco/jui/comments/js/jquery.livequery.js"></script>
<script type="text/javascript" src="/themes/maennaco/jui/comments/js/jquery-ui-timepicker-addon.js"></script>
<script type="text/javascript" src="/themes/maennaco/jui/comments/js/jquery.autosuggest.js"></script>
<link href="/themes/maennaco/jui/comments/css/screen.css?as" type="text/css" rel="stylesheet" />
<link href="/themes/maennaco/jui/comments/css/autosuggest.css" type="text/css" rel="stylesheet" />
<link href="/themes/maennaco/jui/comments/css/fileuploader.css" type="text/css" rel="stylesheet" />

<script src="/themes/maennaco/jui/comments/js/jquery.elastic.js" type="text/javascript" charset="utf-8"></script>
<script src="/themes/maennaco/jui/comments/js/fileuploader.js" type="text/javascript" charset="utf-8"></script>
<script src="/themes/maennaco/jui/comments/js/jquery.watermarkinput.js" type="text/javascript"></script>

<div id='docprev'>
<?php
		
			
		
			
			?>
<script type="text/javascript">

function openDialog(boxtitle, boxcontent,spanAtt){
         
                                $( "#dialog" ).dialog({
                                        autoOpen: true,
                                        width: 500,
                                        title: boxtitle,
                                        height:490,
                                        buttons: { "Close": function() { $(this).dialog("close"); }},
                                        closeOnEscape: true,
                                        modal:true
                                    }).html(boxcontent);
                            
                    }



	$(document).ready(function(){
		
		var currAtt = '';
		var availableTags = {items: [
		//Get the advisors and connected users for the autocomplete feature; $companyid was gotten in the earlier phase in new_company_detail_left.php	
			<?php 
			$Conns = Connections::Com_conns($companyid);
				foreach($Conns['Advisor'] as $Pro)
			    {
				$pro_uid = $Pro->assignee_uid;
				$pro_maeid = getProId($pro_uid);
				echo '{value: "'.$pro_uid.'", name: "'.$pro_maeid.'"},';
			    }
			    
				foreach($Conns['Visible'] as $Pro)
			    {
				$pro_uid = $Pro->assignee_uid;
				$pro_maeid = getProId($pro_uid);
				echo '{value: "'.$pro_uid.'", name: "'.$pro_maeid.'"},';

				foreach($Conns['Client'] as $Pro)
			    {
				$pro_uid = $Pro->assignee_uid;
				$pro_maeid = getProId($pro_uid);
				echo '{value: "'.$pro_uid.'", name: "'.$pro_maeid.'"},';
			    }
			    }
			    $q = mysql_query("SELECT projname FROM maenna_company WHERE companyid = '".$_REQUEST['id']."'");
			    $q = mysql_fetch_array($q);
                            echo '{value: "'.$_REQUEST['id'].'", name: "'.$q['projname'].' "}';
			?>
				]};
				
		
		$('[id^=rmFile]').livequery("click", function(){
			
			fileid = $(this).attr('id').replace("rmFile","");
			
				$.post("/themes/maennaco/includes/posts.php?type=removeFile&fileid="+fileid, {
				
				}, function(response){
				
				$("#file"+fileid).remove();
				
				});
			
			});
		
		$('input[type="file"]').click(function() {
			
			
			});
		$("#showEventForm").click(function() {
			
			$("#eventFormDiv").show("slow");
			
			});
	
		$( "#dialog" ).dialog({
			autoOpen: false
		    });
		
		$(".evedit").livequery("click",function (e) {
			
			e.preventDefault();
			
			eventid = $(this).attr('id').replace('edit_id','');
		
				$.post("/themes/maennaco/includes/posts.php?type=eventEdit&display=true&eventid="+eventid, {
				
				}, function(response){
				
				$( "#eveditdlg" ).dialog({
                                        autoOpen: true,
                                        width: 650,
                                        title: 'Event edit',
                                        height:600,
                                        buttons: { 
						   "Save":  function () {
							
						    title = $("#editEventForm").children("#eventType").val();
						    datetime = $("#editEventForm").children("#eventDate").val();
						    loc = $("#editEventForm").children("#eventLoc").val();
						    agenda = $("#editEventForm").children("#eventDesc").val();
						    uname = '<?=$user->name;?>';
						    cid = <?=$_REQUEST['id'];?>;
						    uid = <?=$user->uid;?>;
						    filesEdit = [];
						    if ($("#chkNot").is(":checked")) notif = 'true'; else notif = false;
						    
						    invitees = $("#editEventForm").children(".as-selections").children(".as-original").children(".as-values").val();
				$(".fileInfo").each(function () {
				var tmpArr1 = {'path':$(this).attr('path'),'title':$(this).attr('filetitle'),'timestamp':$(this).attr('timestamp')};
				filesEdit.push(tmpArr1);
				});
						    
						    $.post("/themes/maennaco/includes/posts.php?type=eventEdit", { eventid: eventid,title:title,datetime:datetime,loc:loc,agenda:agenda,invitees:invitees,u:uname,cid:cid,uid:uid,files:filesEdit,notif:notif},
				       
				       function(response){
					location.reload();
					
					
				
				});
							
							
							
							
						   },
						   "Close": function() { $(this).dialog("close"); }
					
					},
                                        closeOnEscape: true,
                                        modal:true
                                    }).html(response);

				$("#eventInv").autoSuggest(availableTags.items, {selectedItemProp: "name", searchObjProps: "name"});
				$("#eventDesc").elastic();
				$(".as-selections").width(600);
				var uploader1 = new qq.FileUploader({
							// pass the dom node (ex. $(selector)[0] for jQuery users)
							element: $("#file-uploader1")[0],
							// path to server-side upload script
							action: '/themes/maennaco/includes/file_upload.php',
							onComplete: function(id, fileName, responseJSON){
								
								if (responseJSON['success']) {
								$("#eventType").before('<input type="hidden" class="fileInfo" path="'+fileName+'" filetitle="'+$("#fileTitleEdit").val()+'" timestamp = "'+responseJSON['timestamp']+'">');
								$("#fileTitleEdit").val('');
								
								}
								
							}
}); 
				
				});
						
		});
		
		$("#rsvp-button").livequery("click",function () {
		
						status = $('input[name=invStatus]:checked', '#invrsvp').val();
						uid = '<?=$user->uid;?>';
						eventid = $("#dlgInfo").attr('eventid').replace('event','');
						
						$.post("/themes/maennaco/includes/posts.php?type=confirmAtt&status="+status+"&uid="+uid+"&eventid="+eventid, {
			
				}, function(response){
				
				if (response.trim() == 'overlap') { alert("You are already attending event at that time!");  return;}
				
				$("#"+$("#attSpan").val()).html(response);
				
				$( "#dialog" ).dialog("close");
				
				});
						
		});
		
                $(".eventTitle").livequery("click", function(evt){
	
					
				evt.preventDefault();
				eventDiv = $(this).parent().parent().parent();
				eventForm = $(this).parent();
                                ccfiles = $(this).parent().parent().find("<:nth-child(3)");
						
				boxtitle = eventForm.find(">:first-child").html();
				boxcontent = '<span id="dlgInfo" eventid = "'+eventDiv.attr('id')+'" style="float:left; font-size:15px;"><strong>'+eventForm.find("<:first-child").html()+'</strong></span><div id="clear" style="clear:both"></div><span style="float:left;">'+eventForm.find("<:nth-child(3)").html()+'</span><br><span style="float:left;">&nbsp;'+eventForm.find("<:nth-child(5)").html()+'</span><br></div>';
				
				boxcontent = boxcontent + '<div id="clear" style="clear:both"><br>';
				
				if (eventForm.children(".invatt").length > 0) boxcontent= boxcontent + '<div style="float:left;">'+ccfiles.find("<:nth-child(1)").html().replace("rsvp","")+'</div>';
				
				boxcontent = boxcontent+'<div id="clear" style="clear:both"><br><span style="float:left; ">AGENDA:<div style="margin-left:15px;">'+eventForm.find("<:nth-child(7)").html()+'</div> </span><div id="clear" style="clear:both"><br><span style="float:left;">FILES:</span><br><div style="margin-left:15px;>"'+ccfiles.children(".attFiles").html().replace("Attached files:","")+'</div></span>';
				
				
				boxcontent = boxcontent + '<div id="clear" style="clear:both"><br><span style="float:left;">ATTENDING?</span><form style="float:left;" id="invrsvp" action=""><label style="margin-left:20px;"><input type="radio" name="invStatus" value="confirmed" class="styled"><strong>Yes</strong></label><label style="margin-left:20px;"><input type="radio" name="invStatus" value="declined" class="styled"><strong>No</strong></label><label style="margin-left:20px;"><input type="radio" name="invStatus" value="maybe" class="styled"><strong>May be</strong></label><a id="rsvp-button" style="margin-left:30px;" class="small button"> SAVE </a></form>';
				
				
				
				
				if(boxcontent != '') boxcontent = boxcontent.replace(/\\n/g,'<br />');
				$("#attSpan").val("att"+eventDiv.attr('id').replace('event',''));
				openDialog(boxtitle, boxcontent,$(this).parent().attr('id'));
                                    
                                });
		
		                $(".rsvp").livequery("click", function(evt){
					
				evt.preventDefault();
				eventDiv = $(this).parent().parent().parent().parent().parent();
				eventForm = $(this).parent().parent().parent().parent().find("<:first-child");
                                ccfiles = $(this).parent().parent().parent();
						
				boxtitle = eventForm.find(">:first-child").html();
				boxcontent = '<span id="dlgInfo" eventid = "'+eventDiv.attr('id')+'" style="float:left; font-size:15px;"><strong>'+eventForm.find("<:first-child").html()+'</strong></span><div id="clear" style="clear:both"></div><span style="float:left; color:#00a2bf;">'+eventForm.find("<:nth-child(3)").html()+'</span><span style="float:left; color:#00a2bf;">'+eventForm.find("<:nth-child(5)").html()+'</span><br></div>';
				
				boxcontent = boxcontent + '<div id="clear" style="clear:both"><br><span style="float:left;">ATTENDES:</span> <div style="margin-left:15px;float:left;">'+ccfiles.find("<:first-child").html().replace("rsvp","")+'</div>';
				
				boxcontent = boxcontent+'<div id="clear" style="clear:both"><br><span style="float:left; ">AGENDA:<div style="margin-left:15px;">'+eventForm.find("<:nth-child(7)").html()+'</div> </span><div id="clear" style="clear:both"><br><span style="float:left;">FILES:</span><br><div style="margin-left:15px;>"'+ccfiles.children(".attFiles").html().replace("Attached files:","")+'</div></span>';
				
				
				boxcontent = boxcontent + '<div id="clear" style="clear:both"><br><span style="float:left;">ATTENDING?</span><form style="float:left;" id="invrsvp" action=""><label style="margin-left:20px;"><input type="radio" name="invStatus" value="confirmed" class="styled"><strong>Yes</strong></label><label style="margin-left:20px;"><input type="radio" name="invStatus" value="declined" class="styled"><strong>No</strong></label><label style="margin-left:20px;"><input type="radio" name="invStatus" value="maybe" class="styled"><strong>May be</strong></label><a id="rsvp-button" style="margin-left:30px;" class="small button"> SAVE </a></form>';
				
				
	
				
				if(boxcontent != '') boxcontent = boxcontent.replace(/\\n/g,'<br />');
				$("#attSpan").val($(this).parent().attr('id'));
				openDialog(boxtitle, boxcontent,$(this).parent().attr('id'));
                                    
                                });
		
		$("#eventInv").autoSuggest(availableTags.items, {selectedItemProp: "name", searchObjProps: "name"});
			
		$('.qq-upload-remove').livequery("click", function(){
			
			var fileToRemove = $(this).parent().children('.qq-upload-file').html();
			$("input[path='"+fileToRemove+"']").remove();
			$(this).parent().remove();
			});
		$('[id^=shareButton]').livequery("click", function(){
			
			tarea = $('textarea[eventid='+$(this).attr('textref')+']');
			var a = encodeURIComponent(tarea.val());
			var m =  tarea.attr("alt");
			var u =  tarea.attr("name");
                        var uid = '<?=$user->uid;?>';
			var eventid = tarea.attr('eventid');
			

			if(a != "Discuss a topic or ask a question on this file ...")
			{
			 
				$.post("/themes/maennaco/includes/posts.php?type=eventcom&u="+u+"&m="+m+"&value="+a+"&eventid="+eventid+"&uid="+uid, {
			
				}, function(response){
					
					tarea.parent().parent().parent().parent().after($(response).fadeIn('slow'));
					tarea.val("Share ideas on this topic");
					
					$('textarea').elastic();
					$(".commentMark").Watermark("Got advice / question on this topic?");
					tarea.Watermark("watermark","#369");
					
					$(".commentMark").Watermark("watermark","#EEEEEE");
			
				});
			}
		});
		
		//Confirm attendance to event
		//$('a[name=confirmatt]').livequery("click", function(){
		//	
		//	var elm = $(this);
		//	var eventid = elm.attr('eventid');
		//	var uid = <?=$user->uid;?>;
		//	
		//	
		//	
		//		$.post("/themes/maennaco/includes/posts.php?type=confirmAtt&eventId="+eventid+"&uid="+uid, {
		//		
		//		}, function(response){
		//			
		//			elm.replaceWith(response);
		//		
		//		});
		//});
		
		$('#addEvent').click(function(){
			
			
			var uid = <?=$user->uid;?>;
			var m = '<?=md5($user->uid."kyarata75");?>';
			var cid = <?=$_REQUEST['id'];?>;
			var event = $("#eventType").val();
			var loc = $("#eventLoc").val();
			var desc = $("#eventDesc").val();
			var datetime = $("#eventDate").val();
			var invitees = $(".as-values").val();
			var uname = '<?=$user->name;?>';
			var urole = '<?=end($user->roles);?>';
			
			var files= [];
			
			$(".fileInfo").each(function () {
				var tmpArr = {'path':$(this).attr('path'),'title':$(this).attr('filetitle'),'timestamp':$(this).attr('timestamp')};
				files.push(tmpArr);
				});
			
			 
			$.post("/themes/maennaco/includes/posts.php?type=addEvent", { uid: uid, event: event, loc: loc, desc:desc, date: datetime, invitees: invitees,u: uname, files: files,cid: cid,urole:urole,m:m},
				       
				       function(response){
					
					
					$('#posting').prepend($(response).fadeIn('slow'));
					
					$('.fileInfo').remove();
					
					$(".watermark").Watermark("Share ideas on this topic");
					
					$("#eventDate").val("When?");
					$("#eventType").val("Subject?");
					$("#eventLoc").val("Where?");
					$("#eventDesc").val("Agenda?");
					
					$("#eventDate").Watermark("When?");
					$("#eventType").Watermark("Subject?");
					$("#eventLoc").Watermark("Where?");
					$("#eventDesc").Watermark("Agenda?");
					
					$(".watermark").Watermark("watermark","#369");
					$("#eventDate").Watermark("watermark","#369");
					$("#eventType").Watermark("watermark","#369");
					$("#eventLoc").Watermark("watermark","#369");
					$("#eventDesc").Watermark("watermark","#369");
					$("#eventInv").Watermark("watermark","#369");
					
					$("#eventFormDiv").hide("slow");
					
					
			
				});

		});
		
		$('.watermark').livequery("focus", function(e){
		
			sbmBtt = $(this).attr('eventid');
			
			$('a[textref='+sbmBtt+']').show();		
		});
		
		//$('.watermark').livequery("focusout", function(e){
		//
		//	sbmBtt = $(this).attr('eventid');
		//	
		//	$('a[textref='+sbmBtt+']').hide('slow');		
		//});
		
		$('.commentMark').livequery("focus", function(e){
			
			var parent  = $('.commentMark').parent();			
			$(".commentBox").children(".CommentImg").hide();			
		
			var getID =  parent.attr('id').replace('record-','');			
			$("#commentBox-"+getID).children("a#SubmitComment").show();
			
			$("#commentBox-"+getID).children(".CommentImg").show();			
		});	
		
		//showCommentBox
		$('a.showCommentBox').livequery("click", function(e){
			
			var getpID =  $(this).attr('id').replace('post_id','');	
			
			$("#commentBox-"+getpID).css('display','');
			$("#commentMark-"+getpID).focus();
			$("#commentBox-"+getpID).children("CommentImg").show();			
			$("#commentBox-"+getpID).children("a#SubmitComment").show();		
		});	
		
		//SubmitComment
		$('a.comment').livequery("click", function(e){
			
			var getpID =  $(this).parent().attr('id').replace('commentBox-','');	
			var comment_text = encodeURIComponent($("#commentMark-"+getpID).val());
			var m = $(this).parent().attr("alt");
			var u = $(this).parent().attr("name");
                        var uid = '<?=$user->uid;?>';
			
			if(comment_text != "Got advice / question on this topic?")
			{
				$.post("/themes/maennaco/includes/add_comment.php?u="+u+"&comment_text="+comment_text+"&post_id="+getpID+"&m="+m+"&uid="+uid, {
	
				}, function(response){
					
					$('#CommentPosted'+getpID).append($(response).fadeIn('slow'));
					$("#commentMark-"+getpID).val("Got advice / question on this topic?");
										
				});
			}
			
		});	
		
		//more records show
		$('a.more_records').livequery("click", function(e){
			
			var next =  $('a.more_records').attr('id').replace('more_','');
			
			$.post("/themes/maennaco/includes/posts.php?show_more_post="+next, {

			}, function(response){
				$('#bottomMoreButton').remove();
				$('#posting').append($(response).fadeIn('slow'));

			});
			
		});	
		
		//deleteComment
		$('a.c_delete').livequery("click", function(e){
			
			if(confirm('Are you sure you want to delete this comment?')==false)

			return false;
	
			e.preventDefault();
			
			var c_id =  $(this).attr('id').replace('CID-','');	
			var u =  $(this).attr("name");
			var m =  $(this).attr("alt");
			
			$.ajax({

				type: 'get',

				url: '/themes/maennaco/includes/delete_comment.php?c_id='+ c_id+"&u="+u+"&m="+m,

				data: '',

				beforeSend: function(){

				},

				success: function(){

						$('#comment-' + c_id).fadeOut(200,function(){
						
						$('#comment-' + c_id).remove();

					});
					
				}

			});
		});	
		
		/// hover show remove button
		$('.friends_area').livequery("mouseenter", function(e){
			$(this).children("label.name").children("a.delete").show();	
		});	
		$('.friends_area').livequery("mouseleave", function(e){
			$(this).children("label.name").children("a.delete").hide();	
		});
		
		$('.event').livequery("mouseenter", function(e){
			//$(this).children("span").children("a.delete").show();
			$(this).children("a.delete").show();	
		});	
		$('.event').livequery("mouseleave", function(e){
			//$(this).children("span").children("a.delete").hide();
			$(this).children("a.delete").hide();	
		});
		
		
		/// hover show remove button
		
		$('a.evdelete').livequery("click", function(e){

		if(confirm('Are you sure you want to delete this discussion?')==false)

		return false;

		e.preventDefault();
			

		var temp    = $(this).attr('id').replace('remove_id','');
		var u =  $(this).attr("name");
		var m =  $(this).attr("alt");
			
			$.ajax({ 

				type: 'get',

				url: '/themes/maennaco/includes/delete.php?type=event&id='+temp+"&u="+u+"&m="+m,

				data: '',

				beforeSend: function(){

				},

				success: function(){

					$('#event' + temp).fadeOut(200,function(){

						$('#event' + temp).remove();

					});
					
				}

			});
			return true;
			
		
		});
		
		
		
		$('a.delete').livequery("click", function(e){

		if(confirm('Are you sure you want to delete this post?')==false)

		return false;

		e.preventDefault();
			

		var parent  = $('a.delete').parent();

		var temp    = $(this).attr('id').replace('remove_id','');
		var u =  $(this).attr("name");
		var m =  $(this).attr("alt");
		
		var main_tr = $('#'+temp).parent();
		
		
		if ($(this).attr('delType') == 'event') {
			
			
			$.ajax({ 

				type: 'get',

				url: '/themes/maennaco/includes/delete.php?type=event&id='+temp+"&u="+u+"&m="+m,

				data: '',

				beforeSend: function(){

				},

				success: function(){

					$('#event' + temp).fadeOut(200,function(){
						
						$('#event' + temp).remove();

					});
					
				}

			});
			return true;
			
			
		}
					
		$.ajax({ 

				type: 'get',

				url: '/themes/maennaco/includes/delete.php?id='+temp+"&u="+u+"&m="+m,

				data: '',

				beforeSend: function(){

				},

				success: function(){

					$('#record-' + temp).fadeOut(200,function(){
						
						$('#record-' + temp).remove();

					});
					
				}

			});

		});

		$('textarea').elastic();

		jQuery(function($){

		   $(".watermark").Watermark("Share ideas on this topic");
		   $("#eventDate").Watermark("When?");
		   $("#eventType").Watermark("Subject?");
		   $("#eventLoc").Watermark("Where?");
		   $("#eventDesc").Watermark("Agenda?");
		   $("#eventInv").Watermark("+ Add people to notify");
		   $(".commentMark").Watermark("Got advice / question on this topic?");

		});

		jQuery(function($){

		   $(".watermark").Watermark("watermark","#369");
		   $("#eventDate").Watermark("watermark","#369");
		   $("#eventType").Watermark("watermark","#369");
		   $("#eventLoc").Watermark("watermark","#369");
		   $("#eventDesc").Watermark("watermark","#369");
		   $("#eventInv").Watermark("watermark","#369");
		   $(".commentMark").Watermark("watermark","#EEEEEE");

		});	

		function UseData(){

		   $.Watermark.HideAll();

		   //Do Stuff

		   $.Watermark.ShowAll();

		}

	});	

	// ]]>

</script>


	<div> <!--align="center"--> 
	<?php /*if ($_REQUEST['id'] == $user->uid || end($user->roles) == 'Super admin' || end($user->roles) == 'Maennaco admin') { */
	
		if ($AccessObj->Com_sections['discussions']['sections']['nav_menu_right']['access'] == 'write') {
	?>
	
		<!--<a id="showEventForm" class = "small button" style=" font-size:12px;float:right; margin-top:10px;">SCHEDULE A DISCUSSION</a>-->
		
		<div id="eveditdlg"></div>
		<div style="clear:both;"></div>
		<div id="eventFormDiv" style="display:none;" >
		<form action ="" method = "post" name="addEvent" id="addEventForm">
			
			<textarea class="input" id="eventType" name="eventType" cols="60"></textarea><br>
			
			<input type='text' id="eventDate" name="eventDate" class='datepicker' style="15px/160% Verdana, sans-serif;" /><br>
			
			<script type='text/javascript'>
            $(document).ready(function(){
                $("#eventDate").datetimepicker({dateFormat: 'yy-mm-dd'});
		var uploader = new qq.FileUploader({
							// pass the dom node (ex. $(selector)[0] for jQuery users)
							element: $("#file-uploader")[0],
							// path to server-side upload script
							action: '/themes/maennaco/includes/file_upload.php',
							onComplete: function(id, fileName, responseJSON){
								
								if (responseJSON['success']) {
								$("#eventType").before('<input type="hidden" class="fileInfo" path="'+fileName+'" filetitle="'+$("#fileTitle").val()+'" timestamp = "'+responseJSON['timestamp']+'">');
								$("#fileTitle").val('');
								
								}
								
							}
}); 
            });
            </script>
			
			<textarea class="input" id="eventLoc" name="eventLoc" cols="60"></textarea><br>
			
			<textarea class="input" id="eventDesc" name="eventDesc"cols="60"></textarea><br>
			
			<input type='text' id="eventInv" name="eventInv" style="color:333;" /><br>
			
			<!--<textarea class="input" id="eventInv" name="eventInv" style="height:20px" cols="60"></textarea><br>-->
			<div class='editbtn' style="width:60px; position:relative;"><a href='#' class='tool openbox' boxid='evFile'>ATTACH FILE</a></div>
			<div id='evFile' style='text-align:left; display:none'>
				<br>
                            <input style="background:none;float:left;border:solid 2px #DCE6F5;" type=text id="fileTitle" />
                            <div id="file-uploader">
				<noscript>
				    <p>Please enable JavaScript to use file uploader.</p>
				    <!-- or put a simple form for upload here -->
				</noscript>
				
			    </div>
                        <!--<a style="pointer:cursor; float:left; padding:0;" class='hidebox button' boxid=evFile>CLOSE</a>-->
			    <div style="clear:both"></div>
                    </div>
			<?=js_init("init_openbox();init_hidebox();");?>
			<div align="right" style="height:30px; ">

			
				
				<a id="addEvent"  class="tool"> SUBMIT </a>
	
			</div>
			
			<br>
			
			<hr style="color: #E7E6E7;background-color: #E7E6E7;height: 5px;">
			<br>

			
		</form>
		</div>
<?php } ?>	

		<div id="posting" align="left">
		<input id="attSpan" type="hidden" value="">
	
		<?php

		include('dbcon.php');
		
		include_once('events_comments_list.php');
		
		?>
		  
		</div>


	</div>
	</div>