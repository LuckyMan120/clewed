<?php
error_reporting(0);
global $base_url;
include('dbcon.php');
global $user;
$user_id = $user->uid;

$pro_id = sget($_REQUEST, 'pro_id');

$pro_sql = "select * from maenna_professional_payments
				LEFT JOIN maenna_people ON maenna_professional_payments.user_id = maenna_people.pid
				where maenna_professional_payments.pro_id = %d GROUP BY maenna_professional_payments.user_id";
$pro_result = db_query($pro_sql, array($pro_id));
$count = mysql_num_rows($pro_result);
//$pro_row = db_fetch_array($pro_result);
//echo "<pre>"; print_r($pro_row); echo "</pre>";exit;
?>
<div class='month_2' style='border-bottom:none;'>
<?php
if($count > 0)
{
?>
<ul>
<?php
	while($pro_row = db_fetch_array($pro_result))
	{ 
		$gender = $pro_row['gender'];
		if (file_exists($base_url . '/sites/default/images/profiles/117x117/'.$pro_row['user_id'].'.jpg'))
		{ 
			$avatar = $base_url . '/sites/default/images/profiles/117x117/'.$pro_row['user_id'].'.jpg';
		}
		else
		{
			if ($gender == 'm' || $gender == '')
			{ 
				$avatar =$base_url.'/themes/maennaco/images/prof-avatar-male.png';
			}
			else 
			{
				$avatar = $base_url.'/themes/maennaco/images/prof-avatar-female.png';
			}
		}
	
?>
	<li style="list-style:none;background:none;margin:0px 10px 0px 0px;padding:0px;width:35px;height:35px;float:left;">
		<img src="<?php echo $avatar; ?>" style="max-width:35px;" title="<?= ucfirst($pro_row['firstname']) ?>">		
	</li>
<?php } ?>
</ul>

<?php 
	} 
	else
	{
		echo "<p>Currently no users are participating.</p>";
	}
?>
</div>
