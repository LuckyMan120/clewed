<?php
error_reporting(0);
global $base_url;
include('dbcon.php');
global $user;
$user_id = $user->uid;

$pro_id = sget($_REQUEST, 'pro_id');

$pro_sql = "SELECT LDP.post_id, count(*) AS post_count, PWP.post
				FROM like_discussion_posts AS LDP 
				LEFT JOIN pro_wall_posts AS PWP ON PWP.pid = LDP.post_id
				WHERE PWP.flag = 'q' AND LDP.prof_id = $pro_id
				GROUP BY LDP.post_id 
				ORDER BY post_count DESC LIMIT 5";
$pro_result = db_query($pro_sql);
$count = mysql_num_rows($pro_result);
//$pro_row = db_fetch_array($pro_result);
//echo "<pre>"; print_r($pro_row); echo "</pre>";exit;
?>
<div class="month_2">
<?php
if($count > 0)
{
?>
<ul>
<?php
	while($pro_row = db_fetch_array($pro_result))
	{ 
		$post = $pro_row['post'];
		$length = strlen($pro_row['post']);
		if($length > 30)
		{
			$post = substr($pro_row['post'], 0, 30) . '...';
		}
?>
	<li>
		<?php echo ucfirst($post);?>
	</li>
<?php } ?>
</ul>
<?php } 
else {
	echo "Please come back later.";
}
?>
</div>