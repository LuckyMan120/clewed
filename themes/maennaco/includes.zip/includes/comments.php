<script type="text/javascript" src="/themes/maennaco/jui/comments/js/jquery-1.2.6.min.js"></script>
<script type="text/javascript" src="/themes/maennaco/jui/comments/js/jquery.livequery.js"></script>
<script type="text/javascript" src="/themes/maennaco/jui/comments/js/jquery.autosuggest.js"></script>
<link href="/themes/maennaco/jui/comments/css/autosuggest.css" type="text/css" rel="stylesheet" />
<link href="/themes/maennaco/jui/comments/css/screen.css?as" type="text/css" rel="stylesheet" />

<script src="/themes/maennaco/jui/comments/js/jquery.elastic.js" type="text/javascript" charset="utf-8"></script>

<script src="/themes/maennaco/jui/comments/js/jquery.watermarkinput.js" type="text/javascript"></script>

<div id='docprev'>
<script type="text/javascript">

	// <![CDATA[	

	$(document).ready(function(){	

		var availableTags = {items: [
		//Get the advisors and connected users for the autocomplete feature; $companyid was gotten in the earlier phase in new_company_detail_left.php	
			<?php 
			$Conns = Connections::Com_conns($companyid);
				foreach($Conns['Advisor'] as $Pro)
			    {
				$pro_uid = $Pro->assignee_uid;
				$pro_maeid = getProId($pro_uid);
				echo '{value: "'.$pro_uid.'", name: "'.$pro_maeid.'"},';
			    }

				foreach($Conns['Client'] as $Pro)
			    {
				$pro_uid = $Pro->assignee_uid;
				$pro_maeid = getProId($pro_uid);
				echo '{value: "'.$pro_uid.'", name: "'.$pro_maeid.'"},';
			    }
			    $q = mysql_query("SELECT projname FROM maenna_company WHERE companyid = '".$_REQUEST['id']."'");
			    $q = mysql_fetch_array($q);
                            echo '{value: "'.$_REQUEST['id'].'", name: "'.$q['projname'].' "}';
			?>
				]};

                $("#commentsInv").autoSuggest(availableTags.items, {startText: "Invite user", selectedItemProp: "name", searchObjProps: "name"});

        
                $("#watermark").focus(function() {

                $("#submitDiv").show('fast');
                
                });

	$("#watermark").bind('focusout', function() {

              //  $("#submitDiv").hide('fast');
	});

	$('#closeButton').click(function(){ 

		$("#submitDiv").hide('fast');

	});


               
	
		$('#shareButton').click(function(){

			var a = encodeURIComponent($("#watermark").val());
			var doc =  $("#documenturl").attr("title");
			var m =  $("#documenturl").attr("alt");
			var u =  $("#documenturl").attr("name");
                        var uid = '<?=$user->uid?>';
			
			if(a != "Discuss a topic or ask a question on this file ...")
			{
                        
                            var cid = '<?=$_REQUEST['id']?>';
                            var name =  '<?=$_REQUEST['name']?>';
                            var filename =  '<?=$_REQUEST['file']?>';
                            var invitees = $(".as-values").val();
            
                           $.post("/themes/maennaco/includes/posts.php?type=commInv", { cid: cid, name: name, filename: filename, invitees: invitees},
                                                   
                                                   function(response){          
             });

				$.post("/themes/maennaco/includes/posts.php?doc="+doc+"&u="+u+"&m="+m+"&value="+a+"&uid="+uid, {
	
				}, function(response){
					
					$('#posting').prepend($(response).fadeIn('slow'));
					$("#watermark").val("Discuss a topic or ask a question on this file ...");
					
					$('textarea').elastic();
					$(".commentMark").Watermark("Got advice / question on this topic?");
					$("#watermark").Watermark("watermark","#369");
					
					$(".commentMark").Watermark("watermark","#EEEEEE");

					$(".as-selection-item").each(function() {$(this).remove()});

					$(".as-values").val("");

				});
			}
		});	
		
		
		$('.commentMark').livequery("focus", function(e){
			
			var parent  = $('.commentMark').parent();			
			$(".commentBox").children(".CommentImg").hide();			
		
			var getID =  parent.attr('id').replace('record-','');			
			$("#commentBox-"+getID).children("a#SubmitComment").show();
			
			$("#commentBox-"+getID).children(".CommentImg").show();			
		});	
		
		//showCommentBox
		$('a.showCommentBox').livequery("click", function(e){
			
			var getpID =  $(this).attr('id').replace('post_id','');	
			
			$("#commentBox-"+getpID).css('display','');
			$("#commentMark-"+getpID).focus();
			$("#commentBox-"+getpID).children("CommentImg").show();			
			$("#commentBox-"+getpID).children("a#SubmitComment").show();		
		});	
		
		//SubmitComment
		$('a.comment').livequery("click", function(e){
			
			var getpID =  $(this).parent().attr('id').replace('commentBox-','');	
			var comment_text = encodeURIComponent($("#commentMark-"+getpID).val());
			var m =  $("#documenturl").attr("alt");
			var u =  $("#documenturl").attr("name");
                        var uid = '<?=$user->uid?>';
			
			if(comment_text != "Got advice / question on this topic?")
			{
				$.post("/themes/maennaco/includes/add_comment.php?u="+u+"&comment_text="+comment_text+"&post_id="+getpID+"&m="+m+"&uid="+uid, {
	
				}, function(response){
					
					$('#CommentPosted'+getpID).append($(response).fadeIn('slow'));
					$("#commentMark-"+getpID).val("Got advice / question on this topic?");
										
				});
			}
			
		});	
		
		//more records show
		$('a.more_records').livequery("click", function(e){
			
			var next =  $('a.more_records').attr('id').replace('more_','');
			
			$.post("/themes/maennaco/includes/posts.php?show_more_post="+next, {

			}, function(response){
				$('#bottomMoreButton').remove();
				$('#posting').append($(response).fadeIn('slow'));

			});
			
		});	
		
		//deleteComment
		$('a.c_delete').livequery("click", function(e){
			
			if(confirm('Are you sure you want to delete this comment?')==false)

			return false;
	
			e.preventDefault();
			
			var c_id =  $(this).attr('id').replace('CID-','');	
			var u =  $("#documenturl").attr("name");
			var m =  $(this).attr("alt");
			
			$.ajax({

				type: 'get',

				url: '/themes/maennaco/includes/delete_comment.php?c_id='+ c_id+"&u="+u+"&m="+m,

				data: '',

				beforeSend: function(){

				},

				success: function(){

						$('#comment-' + c_id).fadeOut(200,function(){
						
						$('#comment-' + c_id).remove();

					});
					
				}

			});
		});	
		
		/// hover show remove button
		$('.friends_area').livequery("mouseenter", function(e){
			$(this).children("label.name").children("a.delete").show();	
		});	
		$('.friends_area').children("label.name").livequery("mouseleave", function(e){
			$('a.delete').hide();	
		});	
		/// hover show remove button
		
		
		$('a.delete').livequery("click", function(e){

		if(confirm('Are you sure you want to delete this post?')==false)

		return false;

		e.preventDefault();

		var parent  = $('a.delete').parent();

		var temp    = $(this).attr('id').replace('remove_id','');
        		var u =  $(this).attr("name");
		
		var m =  $(this).attr("alt");
		
		var main_tr = $('#'+temp).parent();
					
		$.ajax({ 

				type: 'get',

				url: '/themes/maennaco/includes/delete.php?id='+temp+"&u="+u+"&m="+m,

				data: '',

				beforeSend: function(){

				},

				success: function(){

					$('#record-' + temp).fadeOut(200,function(){
						
						$('#record-' + temp).remove();

					});
					
				}

			});

		});

		$('textarea').elastic();

		jQuery(function($){

		   $("#watermark").Watermark("Discuss a topic or ask a question on this file ...");
		   $(".commentMark").Watermark("Got advice / question on this topic?");

		});

		jQuery(function($){

		   $("#watermark").Watermark("watermark","#369");
		   $(".commentMark").Watermark("watermark","#EEEEEE");

		});	

		function UseData(){

		   $.Watermark.HideAll();

		   //Do Stuff

		   $.Watermark.ShowAll();

		}

	});	

	// ]]>

</script>


	<div align="center">
		
		<div id="documenturl" title="<?php echo basename($url) ?>" name="<?php echo $editorname ?>" alt="<?php  echo md5($editorname."kyarata75") ?>" class="UIComposer_Box" align="center" width="0" height="0" >
		
		</div>
		<?php if (strlen($url)>strlen('http://www.clewed.com')) { ?>
		<iframe src="http://docs.google.com/viewer?url=<?php echo urlencode($url)?>&embedded=true" width="600" height="670" style="border: none;"></iframe>
<br>
	<!--<div class='editbtn' style="width:130px; float:left;position:relative;"><a href='#' class='tool openbox' boxid='evFile'>INVITE FOR COMMENTING</a></div>
			<div id='evFile' style='text-align:left; display:none'>
				<br>
                        <a style="float:left; padding:0;" class='tool' id = "commInv">INVITE</a>
                        <a style="margin-left:20px; float:left; padding:0;" class='hidebox tool' boxid=evFile>CLOSE</a>
			    <div style="clear:both"></div>
                    </div>
			<?=js_init("init_openbox();init_hidebox();");?> -->
<br><br>
<div style="position: relative;margin-bottom:10px; ">
		<form action="" method="post" name="postsForm">
	
		<div class="UIComposer_Box">
	
			<span class="w">
			<textarea class="input" id="watermark" name="watermark" style="height:30px" cols="64"></textarea>
			</span>
		
				<br clear="all" />
				
				<div id="submitDiv" align="right" style="display:none; height:80px; ">
				
					<input type='text' id="commentsInv" name="commentsInv" style="color:333;" />
					<a id="closeButton" class="tool">Close</a>
					<a id="shareButton"  class="tool"> Submit </a>
		
				</div>
				<div style="clear: both;"></div>
		</div>
	
		</form>
		<div style="clear: both;">&nbsp;</div>
		<!--<div style="position: relative;border-bottom:dotted 1px #ccc;bottom: 4px;z-index:-1">
			<div class="discussions">
				Discussions
			</div>
		 </div>-->
		
	</div> 
		

		<div id="posting" align="center">
	
		<?php

		include('dbcon.php');
		
		$check_res = mysql_query("SELECT * FROM wall_documents where document_name = '".  basename($url)."'");
				
		$check_result = mysql_num_rows(@$check_res);
		
		if($check_result == 0)
		{
			mysql_query("INSERT INTO wall_documents (document_name)  VALUES('". basename($url) ."')");
	
		}
		
		
		
		include_once('posts.php');
		
		?>
		  
		</div>
		<?php } else { echo '<div style="margin-top:50px;">Please select a file to view here.</div>'; }?>


	</div>
	</div>