<?php
	include('dbcon.php');
	error_reporting (E_ALL ^ E_NOTICE);


	function nameToId($name) {
	//
	$q = mysql_query("SELECT uid FROM users WHERE name = '".$name."' LIMIT 1") or die(mysql_error());
	$r = mysql_fetch_array($q);
	return $r['uid'];

	}

	function getUserType($uid) {

	$q = mysql_query("SELECT pid FROM maenna_people WHERE pid = '".$uid."' ");

	if (mysql_num_rows($q) > 0 ) return 'people';

	else {
		$q1 = mysql_query("SELECT companyid FROM maenna_company WHERE companyid = '".$uid."' ");
		if (mysql_num_rows($q1) > 0 ) return 'company';
		else return 'admin';
		}
}

	function checkValues($value)
	{
		 // Use this function on all those values where you want to check for both sql injection and cross site scripting
		 //Trim the value
		 $value = trim($value);
		 
		// Stripslashes
		if (get_magic_quotes_gpc()) {
			$value = stripslashes($value);
		}
		
		 // Convert all &lt;, &gt; etc. to normal html and then strip these
		 $value = strtr($value,array_flip(get_html_translation_table(HTML_ENTITIES)));
		
		 // Strip HTML Tags
		 $value = strip_tags($value);
		
		// Quote the value
		$value = mysql_real_escape_string($value);
		$value = htmlspecialchars ($value);
		return $value;
		
	}	
	
	if($_REQUEST['comment_text'] && $_REQUEST['post_id'])
	{
		function getProId($id)
		  {
		      if(empty($id)) return 'invalid id';
		      $sql = mysql_query("SELECT rid FROM users_roles WHERE uid = '".$id."' LIMIT 1 ");
		      $ridn = mysql_fetch_array($sql);
		      if ($ridn['rid'] == '3') {

				$sql = "select users_roles.*, maenna_company.projname from users_roles, maenna_company where users_roles.uid = '".$id."' and maenna_company.companyid = '".$id."' limit 1";


}
		else {

		      $sql = "select users_roles.*, maenna_people.firstname from users_roles, maenna_people where users_roles.uid = '".$id."' and maenna_people.pid = '".$id."' limit 1";
		      
}
		      $result = mysql_query($sql);
		      $Row = mysql_fetch_assoc($result);
		      $rid = $ridn['rid'];
		      $firstname = strtoupper($Row['firstname']);
		      if(in_array($rid, array(6, 10))){
			  $output = "clewed";
		      }elseif ($rid == "3") {
					$output = strtoupper($Row['projname']);

						}
			else
			{
			  $output = "${firstname}MAE" . sprintf("%04s", $id +100);
		      }
		      return $output;
		  }



	    $editorname = getProId($_REQUEST['uid']);

		if (md5($_REQUEST['u']."kyarata75") === $_REQUEST['m'])
		{
		mysql_query("INSERT INTO wall_posts_comments (post_id,comments,f_name,user,date_created) VALUES('".$_REQUEST['post_id']."','".$_REQUEST['comment_text']."','".$editorname."','".$_REQUEST['u']."','".strtotime(date("Y-m-d H:i:s"))."')");
		}
		$result = mysql_query("SELECT *,
		UNIX_TIMESTAMP() - date_created AS CommentTimeSpent FROM wall_posts_comments order by c_id desc limit 1");
	}
	
	function clickable_link($text = '')
	{
		$text = preg_replace('#(script|about|applet|activex|chrome):#is', "\\1:", $text);
		$ret = ' ' . $text;
		$ret = preg_replace("#(^|[\n ])([\w]+?://[\w\#$%&~/.\-;:=,?@\[\]+]*)#is", "\\1<a href=\"\\2\" target=\"_blank\">\\2</a>", $ret);
		
		$ret = preg_replace("#(^|[\n ])((www|ftp)\.[\w\#$%&~/.\-;:=,?@\[\]+]*)#is", "\\1<a href=\"http://\\2\" target=\"_blank\">\\2</a>", $ret);
		$ret = preg_replace("#(^|[\n ])([a-z0-9&\-_.]+?)@([\w\-]+\.([\w\-\.]+\.)*[\w]+)#i", "\\1<a href=\"mailto:\\2@\\3\">\\2@\\3</a>", $ret);
		$ret = substr($ret, 1);
		return $ret;
	}

	function ifAdmin ($uname) {
	 
	 $result = mysql_query("SELECT *  FROM users u WHERE u.name = '".$uname."' AND EXISTS (SELECT * FROM users_roles WHERE uid = u.uid AND rid IN (SELECT rid FROM role WHERE name = 'Super admin' OR name = 'Maennaco admin'))");
	 
	 if (mysql_num_rows($result) > 0 ) {return true;} else return false;
	}

	while ($rows = mysql_fetch_array($result))
	{
		$days2 = floor($rows['CommentTimeSpent'] / (60 * 60 * 24));
		$remainder = $rows['CommentTimeSpent'] % (60 * 60 * 24);
		$hours = floor($remainder / (60 * 60));
		$remainder = $remainder % (60 * 60);
		$minutes = floor($remainder / 60);
		$seconds = $remainder % 60;	?>
		<div class="commentPanel" id="comment-<?php  echo $rows['c_id'];?>" align="left">

<?php
$crId = nameToId($rows['user']);
$uType = getUserType($crId);

if ($uType == 'people' || $uType == 'admin') {

		//Get user gender
		$q1 = mysql_query("SELECT gender FROM maenna_people WHERE pid = $pro_uid");
		$gender_tmp = mysql_fetch_array($q1);
		$gender = $gender_tmp['gender'];

if (file_exists('sites/default/images/profiles/50x50/'.$crId.'.jpg')) { $avatar = 'sites/default/images/profiles/50x50/'.$crId.'.jpg';} 
		  else {
				if ($gender == 'm' || $gender == '') { $avatar =' /themes/maennaco/images/prof-avatar-male.png';}

					else $avatar = '/themes/maennaco/images/prof-avatar-female.png';
			}
}
else if ($uType == 'company')  {

//Get cmp_role		
		$q1 = mysql_query("SELECT company_type FROM maenna_company WHERE companyid = $crId") or die(mysql_error());
		$cmp_role_tmp = mysql_fetch_array($q1);
		$cmp_role = $cmp_role_tmp['company_type'];
		 //Check if user have a profile picture
		  if (file_exists('sites/default/images/company/50x50/'.$crId.'.jpg')) {$avatar = 'sites/default/images/company/50x50/'.$crId.'.jpg';} 
		  else	
				if ($cmp_role == 'service') $avatar =' /themes/maennaco/images/cmp-avatar-service.png';
				else $avatar =' /themes/maennaco/images/cmp-avatar-product.png';

}
                        
echo "<img src=".$avatar." style=\"float:left;margin-top:5px; margin-right:5px; width:35px; height:35px;\">";

?>
			<label style="width:85%;" class="postedComments">
				<span ><b><?php if (ifAdmin($rows['user'])) {echo "clewed";} else  echo $rows['f_name']; echo "</b><span style='color:#666;'>&nbsp;continues discussion:</span>";?></span>
				<?php  echo nl2br($rows['comments']);?>
			
			<br><span style="display:inline-block;width:90px; color:#666666; font-size:11px">
			<?php
						if($days2 > 0)
						echo date('F d Y H:i:s', $rows['date_created']);
						elseif($days2 == 0 && $hours == 0 && $minutes == 0)
						echo "few seconds ago";		
						elseif($days2 == 0 && $hours == 0)
						echo $minutes.' minutes ago';
						else
			echo "few seconds ago";	
?>
			</span>
			
			<?php
			
			if($rows['user'] == $_REQUEST['u']){?>
			&nbsp;&nbsp;<a href="#" id="CID-<?php  echo $rows['c_id'];?>" alt="<?php  echo md5($rows['c_id'].$rows['user']."kyarata75") ?>" name="<?=$rows['user'];?>" class="c_delete tool">Delete</a>
			<?php
			}?>
		</div></label>
	<?php
	}?>	

		
		
		
		