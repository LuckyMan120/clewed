<?php

chdir('../../../');
require_once './includes/bootstrap.inc';
drupal_bootstrap(DRUPAL_BOOTSTRAP_FULL);

$return = menu_execute_active_handler();

if (is_int($return)) {
    switch ($return) {
        case MENU_NOT_FOUND:
            drupal_not_found();
            break;
        case MENU_ACCESS_DENIED:
            drupal_access_denied();
            break;
        case MENU_SITE_OFFLINE:
            drupal_site_offline();
            break;
    }
}

if ($_REQUEST['type'] == 'changeProjectName') {

    if (md5($_REQUEST['cid'].'kyarata75') == $_REQUEST['m']) {


       $sql = "select projname from maenna_company WHERE projname = '%s'";
       $result = db_query($sql,array($_REQUEST['proj_name']));
       if ($result) {

           if (mysql_num_rows($result) == 0) {

               $sql = "update maenna_company SET projname = '%s' WHERE companyid = %d ";
               $result = db_query($sql,array($_REQUEST['proj_name'],$_REQUEST['cid']));
               if ($result) {

                   die('Project name changed successfully');

               }
               else die('Error happened.Please try again');

           }

           else die('Project name is already taken. Try another one');
       }


    }

    else die('Authentication problem!');

}

function isApproved($uid) {

    $result = mysql_query ("SELECT approved FROM maenna_people WHERE pid = $uid LIMIT 1 ");

    $Row = mysql_fetch_object($result);

    return $Row->approved;


}

if ($_REQUEST['type'] = 'checkApproved') {

    $anyNotApproved = false;

    $selected_uid = $_REQUEST['uids'];
    if ($selected_uid == ',')
        $selected_uid = '';
    $UID = array();
    if ($selected_uid) {
        $A = explode(',', $selected_uid);
        foreach ($A as $id) {
            $UID[] = trim($id);
        }
    }

    foreach ($UID as $uid) {

        if ($uid != '')
            if (!isApproved($uid)) die('false');
    }

    die ('true');


}

?>