<?php
	include('dbcon.php');

	
	if ($_REQUEST['type'] == 'professional_images') {
		
		$sql = "delete from maenna_professional_file where professional_id = '".$_POST['event_id']."' AND id = '" . $_REQUEST['image_id'] . "'";
		$query = mysql_query($sql);
		if($query)
		{
			echo 1;
		}
	
	}
	
	if ($_REQUEST['type'] == 'professional_links') {
		
		$sql = "delete from maenna_professional_links where professional_id = '".$_POST['event_id']."' AND id = '" . $_REQUEST['link_id'] . "'";
		$query = mysql_query($sql);
		if($query)
		{
			echo 1;
		}
	
	}
	
	
	
	if (md5($_REQUEST['id'].$_REQUEST['u']."kyarata75") === $_REQUEST['m'])
	{	
		
		if ($_REQUEST['type'] == 'event') {
		
		$event = mysql_query ("SELECT * FROM maenna_company_events WHERE eventid = '".$_REQUEST['id']."'");
		$event = mysql_fetch_array($event);

		$inv = mysql_query ("SELECT mail FROM maenna_company_events_inv mcei JOIN users u ON mcei.uid = u.uid WHERE eventid = '".$_REQUEST['id']."' AND mcei.status = 'confirmed'");

		mysql_query("delete from maenna_company_events where eventid = '".$_REQUEST['id']."'");
		mysql_query("delete from maenna_company_events_inv where eventid = '".$_REQUEST['id']."'");
		mysql_query("delete from wall_posts where p_id ='".$_REQUEST['id']."' AND user ='".$_REQUEST['u']."'");
		mysql_query("delete from wall_posts_comments where post_id ='".$_REQUEST['id']."'");
		mysql_query("delete from maenna_company_data where data_type = 'events' AND data_value6 ='".$_REQUEST['id']."'");

		
		while ($invm = mysql_fetch_array($inv)) {

	 $to      = $invm['mail'];
	 $subject = '[Event canceled] '.strtoupper($event['title']);
	 $message.= 'Event: '.strtoupper($event['title']).'<br><br>';
	 $message.= 'Unfortunately, this event has been canceled!!!<br><br>';
	 $message.= 'Best regards<br>';
	 $message.= 'CLEWED TEAM';
	 $headers = "From: admin@maennaco.com \r\n";
	 $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

	 mail($to, $subject, $message, $headers) or die('neuspeh');

}

}

else {

		mysql_query("delete from wall_posts where p_id ='".$_REQUEST['id']."' AND user ='".$_REQUEST['u']."'");
		mysql_query("delete from wall_posts_comments where post_id ='".$_REQUEST['id']."'");

}
	}
if ($_REQUEST['type'] == 'professional') {
	mysql_query("delete from maenna_professional where id = '".$_REQUEST['id']."'");
}

if ($_REQUEST['type'] == 'professional_post') {
	mysql_query("delete from pro_wall_posts where pid = '".$_REQUEST['id']."'");
	
	mysql_query("delete from pro_wall_posts_comments where post_id = '".$_REQUEST['id']."'");
}

if ($_REQUEST['type'] == 'professional_comments') {
	mysql_query("delete from pro_wall_posts_comments where cid = '".$_REQUEST['id']."'");
}

if($_REQUEST['type'] == 'like_discussion')
{
	if($_REQUEST['status'] == 1)
		mysql_query("INSERT INTO like_discussion_professional (prof_id,user_id) VALUES('".$_REQUEST['prof_id']."','".$_REQUEST['userid']."')");
	else
		mysql_query("delete from like_discussion_professional where prof_id = '".$_REQUEST['prof_id']."' and user_id = '".$_REQUEST['userid']."' ");
}

if($_REQUEST['type'] == 'like_posts')
{
	if($_REQUEST['status'] == 1)
		mysql_query("INSERT INTO like_discussion_posts (prof_id,post_id,user_id) VALUES('".$_REQUEST['prof_id']."','".$_REQUEST['post_id']."','".$_REQUEST['userid']."')");
	else
		mysql_query("delete from like_discussion_posts where prof_id = '".$_REQUEST['prof_id']."' and post_id = '".$_REQUEST['post_id']."' and user_id = '".$_REQUEST['userid']."' ");
}

if($_REQUEST['type'] == 'like_company')
{
	if($_REQUEST['status'] == 1)
		mysql_query("INSERT INTO like_company (user_id,project_id) VALUES('".$_REQUEST['user_id']."','".$_REQUEST['project_id']."')");
	else
		mysql_query("delete from like_company where project_id = '".$_REQUEST['project_id']."' and user_id = '".$_REQUEST['user_id']."' ");
}

if($_REQUEST['type'] == 'follow')
{
	
	if($_REQUEST['status'] == 1)
	
		mysql_query("INSERT INTO maennaco_follow (discussion_id,user_id) VALUES('".$_REQUEST['id']."','".$_REQUEST['user_id']."')");
	else
		mysql_query("delete from maennaco_follow where discussion_id = '".$_REQUEST['id']."' and user_id = '".$_REQUEST['user_id']."' ");
}

if($_REQUEST['type'] == 'join')
{
	mysql_query("INSERT INTO maenna_professional_payments (user_id,pro_id,transaction_id,amount,status, date_created) VALUES('".$_REQUEST['uid']."','".$_REQUEST['prof_id']."','','0','1', '".strtotime(date("Y-m-d H:i:s"))."')");
	$spots = mysql_query("SELECT spots FROM maenna_professional WHERE id = '".$_REQUEST['prof_id']."'");
	$sports_result = mysql_fetch_array($spots);
	if(mysql_num_rows($spots) == 1)
	{
		if($sports_result['spots'] >= 1)
		{
			$spots_count = $sports_result['spots'] - 1;
		}else {
			$spots_count = 0;
		}
		
		
		mysql_query("UPDATE maenna_professional SET spots = '".$spots_count."' WHERE id='" .$_REQUEST['prof_id']. "'");
		
	}
	
}

if($_REQUEST['type'] = 'discussion_status')
{
	if($_REQUEST['status'] == 1)
	{
		$status = 0;
	}else
	{
		$status = 1;
	}
	mysql_query("UPDATE maenna_people SET discussion_status = '" .$status. "' WHERE pid='" .$_REQUEST['id']. "'");
	echo 1;
}
?>