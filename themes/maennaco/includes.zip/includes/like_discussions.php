<?php
error_reporting(0);
global $base_url;
include('dbcon.php');
global $user;
$pro_id = sget($_REQUEST, 'pro_id');
$id = sget($_REQUEST, 'id');
$result1 = mysql_query ("SELECT * FROM  `maenna_professional` WHERE  id = '".$pro_id."' ORDER BY id DESC ");
$row1 = mysql_fetch_array($result1);
$result3 = mysql_query ("SELECT * 
					     FROM  `like_discussion_professional` 
					     WHERE  prof_id = '".$row1['id']."' and user_id = '".$id."'");
  $sql_likes = mysql_query ("SELECT * FROM  `like_discussion_professional` WHERE `user_id` = '" . $id."' AND `prof_id` = '" . $row1['id']."' ORDER BY id DESC");
  $sql_likes_result = mysql_num_rows($sql_likes);

$likepost = mysql_num_rows($result3);
$likepostArray = mysql_fetch_array($result3);

 if($likepost == 1 && $id == $likepostArray['user_id']) { ?>
		<p style='text-align: center;'><a style="cursor:pointer; color:#00A3BF;" onclick="like_discussion('unlike', '<?=$row1['id']?>','<?=$id?>');">Unlike</a>  <?php echo ($sql_likes_result != '0') ? $sql_likes_result : '0'; ?></p>
	   <?php } else {?>
	   <p style='text-align: center;'><a style="cursor:pointer;color:#00A3BF;" onclick="like_discussion('like', '<?=$row1['id']?>','<?=$id?>');">Like</a> <?php echo ($sql_likes_result != '0') ? $sql_likes_result : '0'; ?></p>
	<?php } ?>
<script type="text/javascript">
	function like_discussion(type, prof_id, userid)
	{
	
	if(type == 'like')
		var status = 1;
	else
		var status = 0;
	
	$.ajax({ 

				type: 'get',

				url: '<?php echo $base_url; ?>/themes/maennaco/includes/delete.php?type=like_discussion&prof_id='+prof_id+'&userid='+userid+'&status='+status,

				data: '',

				beforeSend: function(){

				},

				success: function(){

								location.reload();
								/*if(type == 'like')
								{
									$('#likepost').html("<a style='cursor:pointer;' onclick='like_discussion(\"unlike\", "+prof_id+","+userid+");'>Unlike</a>");
								}
								else
								{
									$('#likepost').html("<a style='cursor:pointer;' onclick='like_discussion(\"like\", "+prof_id+","+userid+");'>Like</a>");
								}*/
					
				}

			});
	}

</script>