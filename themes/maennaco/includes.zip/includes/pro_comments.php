<?php
error_reporting(0);
global $base_url;
include('dbcon.php');
$id = sget($_REQUEST, 'id');

$sql_schedule = "SELECT discussion_status FROM maenna_people WHERE pid=" . $_REQUEST['id'];
$dis_query = mysql_query($sql_schedule);
$result_dis = mysql_fetch_object($dis_query);

?>
<script type="text/javascript" src="<?php echo $base_url; ?>/themes/maennaco/jui/comments/js/jquery.livequery.js"></script>
<script type="text/javascript" src="<?php echo $base_url; ?>/themes/maennaco/jui/comments/js/jquery-ui-timepicker-addon.js"></script>
<script type="text/javascript" src="<?php echo $base_url; ?>/themes/maennaco/jui/js/jquery.formatCurrency.js"></script>

<script type="text/javascript" src="<?php echo $base_url; ?>/themes/maennaco/jui/comments/js/jquery.autosuggest.js"></script>
<link href="<?php echo $base_url; ?>/themes/maennaco/jui/comments/css/screen.css?as" type="text/css" rel="stylesheet" />
<link href="<?php echo $base_url; ?>/themes/maennaco/jui/comments/css/autosuggest.css" type="text/css" rel="stylesheet" />
<link href="<?php echo $base_url; ?>/themes/maennaco/jui/comments/css/fileuploader.css" type="text/css" rel="stylesheet" />

<script src="<?php echo $base_url; ?>/themes/maennaco/jui/comments/js/jquery.elastic.js" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo $base_url; ?>/themes/maennaco/jui/comments/js/fileuploader.js" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo $base_url; ?>/themes/maennaco/jui/comments/js/jquery.watermarkinput.js" type="text/javascript"></script>

<style type="text/css">
div.content_box .box_title {
margin-top:14px;
}
</style>

<div id='docprev'>
<?php
		
			
		
			
			?>
<script type="text/javascript">

function openDialog(boxtitle, boxcontent,spanAtt){
         
                                $( "#dialog" ).dialog({
                                        autoOpen: true,
                                        width: 500,
                                        title: boxtitle,
                                        height:490,
                                        buttons: { "Close": function() { $(this).dialog("close"); }},
                                        closeOnEscape: true,
                                        modal:true
                                    }).html(boxcontent);
                            
                    }



	$(document).ready(function(){
		

		$('#cost').blur(function()
		{
			$('#cost').formatCurrency();
		});
		
		
		var currAtt = '';
		var availableTags = {items: [
		//Get the advisors and connected users for the autocomplete feature; $companyid was gotten in the earlier phase in new_company_detail_left.php	
			<?php 
			$Conns = Connections::Com_conns($companyid);
				foreach($Conns['Advisor'] as $Pro)
			    {
				$pro_uid = $Pro->assignee_uid;
				$pro_maeid = getProId($pro_uid);
				echo '{value: "'.$pro_uid.'", name: "'.$pro_maeid.'"},';
			    }
			    
				foreach($Conns['Visible'] as $Pro)
			    {
				$pro_uid = $Pro->assignee_uid;
				$pro_maeid = getProId($pro_uid);
				echo '{value: "'.$pro_uid.'", name: "'.$pro_maeid.'"},';

				foreach($Conns['Client'] as $Pro)
			    {
				$pro_uid = $Pro->assignee_uid;
				$pro_maeid = getProId($pro_uid);
				echo '{value: "'.$pro_uid.'", name: "'.$pro_maeid.'"},';
			    }
			    }
			    $q = mysql_query("SELECT projname FROM maenna_company WHERE companyid = '".$_REQUEST['id']."'");
			    $q = mysql_fetch_array($q);
                            echo '{value: "'.$_REQUEST['id'].'", name: "'.$q['projname'].' "}';
			?>
				]};
				
		
		$('[id^=rmFile]').livequery("click", function(){
			
			fileid = $(this).attr('id').replace("rmFile","");
			
				$.post("<?php echo $base_url; ?>/themes/maennaco/includes/posts.php?type=removeFile&fileid="+fileid, {
				
				}, function(response){
				
				$("#file"+fileid).remove();
				
				});
			
			});
		
		$('input[type="file"]').click(function() {
			
			
			});
		$("#showEventForm").click(function() {
			
			var discussion_status = "<?php echo $result_dis->discussion_status; ?>";
			if(discussion_status == 1)
			{
				$("#eventFormDiv").show("slow");
			}else
			{
				alert("Organizing a discussion requires screening and approval. Please contact your admin to complete this process");
				return false;
			}
			
			});
	
		$( "#dialog" ).dialog({
			autoOpen: false
		    });
		$(".profile_details").livequery("click",function (e) {
		
			
			e.preventDefault();
			var eventid = $(this).attr('id').replace('edit_id','');
			uid = <?=$user->uid;?>;
			$.post("<?php echo $base_url; ?>/themes/maennaco/includes/pro_posts.php?type=profileInfo&display=true&eventid="+eventid+"&uid="+uid+"&base_url=<?php echo $base_url;?>", {
				
				}, function(response){
				
				$( "#eveditdlg" ).dialog({
									autoOpen: true,
									width: 650,
									title: 'PROFILE',
									resizable: false,
									draggable: false,
									height:400,
									closeText: 'hide',
									buttons: { 
						/*"Close": function() { $(this).dialog("close"); }*/
					
					}, closeOnEscape: true,
					   modal:true
					}).html(response);
				});
			});
		
		
		$(".evedit").livequery("click",function (e) {
		
			
			e.preventDefault();
			
			var eventid = $(this).attr('id').replace('edit_id','');
		
			$.post("<?php echo $base_url; ?>/themes/maennaco/includes/pro_posts.php?type=eventEdit&display=true&eventid="+eventid, {
				
				}, function(response){
				
				$( "#eveditdlg" ).dialog({
                                        autoOpen: true,
                                        width: 650,
                                        title: 'Event edit',
										resizable: false,
										draggable: false,
										open:function () {
										$(this).closest(".ui-dialog").find(".ui-button:first").next().find(".ui-button-text").addClass("uicancel"); },
                                        height:600,
                                        buttons: { 
						   "Save":  function () {
							links = '';
							name = '';
						    title = $("#editEventForm").children("#eventType").val();
							var name = new Array();
							var links = new Array();
							$("#text input[name=name]").each(function() {
							   name.push($(this).val());
							});
							
							var taskArray = new Array();
							$("#text input[name=link]").each(function() {
							   links.push($(this).val());
							});
							
							names = name;
							links = links;
						    datetime = $("#editEventForm").children("#date").val();
						    loc = $("#editEventForm").children("#eventLoc").val();
						    agenda = $("#editEventForm").children("#eventDesc").val();
							eventcost = $("#editEventForm").children("#eventCost").val();
							eventcapacity = $("#editEventForm").children("#eventCapacity").val();
							eventtags = $("#editEventForm").children("#eventTags").val();
						    uname = '<?=$user->name;?>';
						    cid = <?=$_REQUEST['id'];?>;
						    uid = <?=$user->uid;?>;
						    filesEdit = [];
						    if ($("#chkNot").is(":checked")) notif = 'true'; else notif = false;
						    
						    invitees = $("#editEventForm").children(".as-selections").children(".as-original").children(".as-values").val();
				$(".fileInfo").each(function () {
				var tmpArr1 = {'path':$(this).attr('path'),'title':$(this).attr('filetitle'),'timestamp':$(this).attr('timestamp')};
				filesEdit.push(tmpArr1);
				});
						    
						    $.post("<?php echo $base_url; ?>/themes/maennaco/includes/pro_posts.php?type=eventEdit", { eventid: eventid,title:title,datetime:datetime,loc:loc,agenda:agenda,cost:eventcost,capacity:eventcapacity,tags:eventtags,u:uname,cid:cid,uid:uid,files:filesEdit,notif:notif,links:links, names:names},
				       
				       function(response){
							location.reload();
				});
							
						   },
						   "Close": function() { $(this).dialog("close"); }
					
					},
                                        closeOnEscape: true,
                                        modal:true
                                    }).html(response);

				$("#eventInv").autoSuggest(availableTags.items, {selectedItemProp: "name", searchObjProps: "name"});
				$("#eventDesc").elastic();
				$(".as-selections").width(600);
				var uploader1 = new qq.FileUploader({
							// pass the dom node (ex. $(selector)[0] for jQuery users)
							element: $("#file-uploader1")[0],
							dataType:'json',
							// path to server-side upload script
							action: '<?php echo $base_url; ?>/themes/maennaco/includes/file_upload.php',
							
							onComplete: function(id, fileName, responseJSON){
								
								if (responseJSON['success']) {
									
									$("#eventType").before('<input type="hidden" class="fileInfo" path="'+fileName+'" filetitle="'+$("#fileTitleEdit").val()+'" timestamp = "'+responseJSON['timestamp']+'">');
									$("#fileTitleEdit").val('');
								
								}
								
							}
}); 
				
				});
						
		});
		
		
		
		/********* Attach Files  *********/
		
			$(".file").livequery("click",function (e) {
			
			e.preventDefault();
			
			fileid = $(this).attr('id').replace('file_id','');
		
				$.post("<?php echo $base_url; ?>/themes/maennaco/includes/pro_posts_files.php?type=attachFile", {
				
				}, function(response){
				
				$( "#eveditdlg" ).dialog({
                                        autoOpen: true,
                                        width: 650,
                                        title: 'File Attachment',
                                        height:300,
                                        buttons: { 
						   "Save":  function () {
							
						    title = $("#editEventForm #event").children("#eventType").val();
							/*var title = '';
							$("#event textarea").each(function () {
								title += $(this).val() + '###';
							});*/
							var name = new Array();
							var links = new Array();
							$("#text input[name=name]").each(function() {
							   name.push($(this).val());
							});
							
							var taskArray = new Array();
							$("#text input[name=link]").each(function() {
							   links.push($(this).val());
							});
							
							datetime = $("#editEventForm").children("#eventDate").val();
						    loc = $("#editEventForm").children("#eventLoc").val();
						    agenda = $("#editEventForm").children("#eventDesc").val();
						    uname = '<?=$user->name;?>';
						    cid = <?=$_REQUEST['id'];?>;
						    uid = <?=$user->uid;?>;
						    filesEdit = [];
						    if ($("#chkNot").is(":checked")) notif = 'true'; else notif = false;
						    
						    invitees = $("#editEventForm").children(".as-selections").children(".as-original").children(".as-values").val();
				$(".fileInfo").each(function () {
				var tmpArr1 = {'path':$(this).attr('path'),'title':$(this).attr('filetitle'),'timestamp':$(this).attr('timestamp')};
				filesEdit.push(tmpArr1);
				});
						    
							$.post("<?php echo $base_url; ?>/themes/maennaco/includes/pro_posts_files.php?type=attachFile", { title:title,datetime:datetime,loc:loc,agenda:agenda,invitees:invitees,u:uname,cid:cid,uid:uid,files:filesEdit,notif:notif, names:name, links:links},
				       
				       function(response){
						//location.reload();
						$('#eveditdlg').dialog("close");
					
					
				
				});
							
							
							
							
						   },
						   "Close": function() { $(this).dialog("close"); }
					
					},
                                        closeOnEscape: true,
                                        modal:true
                                    }).html(response);

				$("#eventInv").autoSuggest(availableTags.items, {selectedItemProp: "name", searchObjProps: "name"});
				$("#eventDesc").elastic();
				$(".as-selections").width(600);
				var uploader1 = new qq.FileUploader({
							// pass the dom node (ex. $(selector)[0] for jQuery users)
							element: $("#file-uploader1")[0],
							// path to server-side upload script
							action: '<?php echo $base_url; ?>/themes/maennaco/includes/file_upload.php',
							onComplete: function(id, fileName, responseJSON){
								
								if (responseJSON['success']) {
								$("#eventType").before('<input type="hidden" class="fileInfo" path="'+fileName+'" filetitle="'+$("#fileTitleEdit").val()+'" timestamp = "'+responseJSON['timestamp']+'">');
								$("#fileTitleEdit").val('');
								
								}
								
							}
}); 
				
				});
						
		});
		
		/******** End Attach Files **********/
		
		$("#rsvp-button").livequery("click",function () {
		
						status = $('input[name=invStatus]:checked', '#invrsvp').val();
						uid = '<?=$user->uid;?>';
						eventid = $("#dlgInfo").attr('eventid').replace('event','');
						
						$.post("<?php echo $base_url; ?>/themes/maennaco/includes/posts.php?type=confirmAtt&status="+status+"&uid="+uid+"&eventid="+eventid, {
			
				}, function(response){
				
				if (response.trim() == 'overlap') { alert("You are already attending event at that time!");  return;}
				
				$("#"+$("#attSpan").val()).html(response);
				
				$( "#dialog" ).dialog("close");
				
				});
						
		});
		
                $(".eventTitle").livequery("click", function(evt){
	
					
				evt.preventDefault();
				eventDiv = $(this).parent().parent().parent();
				eventForm = $(this).parent();
                                ccfiles = $(this).parent().parent().find("<:nth-child(3)");
						
				boxtitle = eventForm.find(">:first-child").html();
				boxcontent = '<span id="dlgInfo" eventid = "'+eventDiv.attr('id')+'" style="float:left; font-size:15px;"><strong>'+eventForm.find("<:first-child").html()+'</strong></span><div id="clear" style="clear:both"></div><span style="float:left;">'+eventForm.find("<:nth-child(3)").html()+'</span><br><span style="float:left;">&nbsp;'+eventForm.find("<:nth-child(5)").html()+'</span><br></div>';
				
				boxcontent = boxcontent + '<div id="clear" style="clear:both"><br>';
				
				if (eventForm.children(".invatt").length > 0) boxcontent= boxcontent + '<div style="float:left;">'+ccfiles.find("<:nth-child(1)").html().replace("rsvp","")+'</div>';
				
				boxcontent = boxcontent+'<div id="clear" style="clear:both"><br><span style="float:left; ">AGENDA:<div style="margin-left:15px;">'+eventForm.find("<:nth-child(7)").html()+'</div> </span><div id="clear" style="clear:both"><br><span style="float:left;">FILES:</span><br><div style="margin-left:15px;>"'+ccfiles.children(".attFiles").html().replace("Attached files:","")+'</div></span>';
				
				
				boxcontent = boxcontent + '<div id="clear" style="clear:both"><br><span style="float:left;">ATTENDING?</span><form style="float:left;" id="invrsvp" action=""><label style="margin-left:20px;"><input type="radio" name="invStatus" value="confirmed" class="styled"><strong>Yes</strong></label><label style="margin-left:20px;"><input type="radio" name="invStatus" value="declined" class="styled"><strong>No</strong></label><label style="margin-left:20px;"><input type="radio" name="invStatus" value="maybe" class="styled"><strong>May be</strong></label><a id="rsvp-button" style="margin-left:30px;" class="small button"> SAVE </a></form>';
				
				
				
				
				if(boxcontent != '') boxcontent = boxcontent.replace(/\\n/g,'<br />');
				$("#attSpan").val("att"+eventDiv.attr('id').replace('event',''));
				openDialog(boxtitle, boxcontent,$(this).parent().attr('id'));
                                    
                                });
		
		                $(".rsvp").livequery("click", function(evt){
					
				evt.preventDefault();
				eventDiv = $(this).parent().parent().parent().parent().parent();
				eventForm = $(this).parent().parent().parent().parent().find("<:first-child");
                                ccfiles = $(this).parent().parent().parent();
						
				boxtitle = eventForm.find(">:first-child").html();
				boxcontent = '<span id="dlgInfo" eventid = "'+eventDiv.attr('id')+'" style="float:left; font-size:15px;"><strong>'+eventForm.find("<:first-child").html()+'</strong></span><div id="clear" style="clear:both"></div><span style="float:left; color:#6792D0;">'+eventForm.find("<:nth-child(3)").html()+'</span><span style="float:left; color:#6792D0;">'+eventForm.find("<:nth-child(5)").html()+'</span><br></div>';
				
				boxcontent = boxcontent + '<div id="clear" style="clear:both"><br><span style="float:left;">ATTENDES:</span> <div style="margin-left:15px;float:left;">'+ccfiles.find("<:first-child").html().replace("rsvp","")+'</div>';
				
				boxcontent = boxcontent+'<div id="clear" style="clear:both"><br><span style="float:left; ">AGENDA:<div style="margin-left:15px;">'+eventForm.find("<:nth-child(7)").html()+'</div> </span><div id="clear" style="clear:both"><br><span style="float:left;">FILES:</span><br><div style="margin-left:15px;>"'+ccfiles.children(".attFiles").html().replace("Attached files:","")+'</div></span>';
				
				
				boxcontent = boxcontent + '<div id="clear" style="clear:both"><br><span style="float:left;">ATTENDING?</span><form style="float:left;" id="invrsvp" action=""><label style="margin-left:20px;"><input type="radio" name="invStatus" value="confirmed" class="styled"><strong>Yes</strong></label><label style="margin-left:20px;"><input type="radio" name="invStatus" value="declined" class="styled"><strong>No</strong></label><label style="margin-left:20px;"><input type="radio" name="invStatus" value="maybe" class="styled"><strong>May be</strong></label><a id="rsvp-button" style="margin-left:30px;" class="small button"> SAVE </a></form>';
				
				
	
				
				if(boxcontent != '') boxcontent = boxcontent.replace(/\\n/g,'<br />');
				$("#attSpan").val($(this).parent().attr('id'));
				openDialog(boxtitle, boxcontent,$(this).parent().attr('id'));
                                    
                                });
		
		$("#eventInv").autoSuggest(availableTags.items, {selectedItemProp: "name", searchObjProps: "name"});
			
		$('.qq-upload-remove').live("click", function(){
		
			
			var fileToRemove = $(this).parent().children('.qq-upload-file').html();
			$("input[path='"+fileToRemove+"']").remove();
			$(this).parent().remove();
			});
		$('[id^=shareButton]').livequery("click", function(){
			
			tarea = $('textarea[eventid='+$(this).attr('textref')+']');
			var a = encodeURIComponent(tarea.val());
			var m =  tarea.attr("alt");
			var u =  tarea.attr("name");
                        var uid = '<?=$user->uid;?>';
			var eventid = tarea.attr('eventid');
			
			if(a != "Discuss a topic or ask a question on this file ...")
			{
			 
				$.post("<?php echo $base_url; ?>/themes/maennaco/includes/pro_posts_files.php?type=eventcom&u="+u+"&m="+m+"&value="+a+"&eventid="+eventid+"&uid="+uid, {
			
				}, function(response){
					
					tarea.parent().parent().parent().parent().after($(response).fadeIn('slow'));
					tarea.val("Share ideas on this topic");
					
					$('textarea').elastic();
					$(".commentMark").Watermark("Got advice / question on this topic?");
					tarea.Watermark("watermark","#369");
					
					$(".commentMark").Watermark("watermark","#EEEEEE");
			
				});
			}
		});
		
		//Confirm attendance to event
		//$('a[name=confirmatt]').livequery("click", function(){
		//	
		//	var elm = $(this);
		//	var eventid = elm.attr('eventid');
		//	var uid = <?=$user->uid;?>;
		//	
		//	
		//	
		//		$.post("/themes/maennaco/includes/posts.php?type=confirmAtt&eventId="+eventid+"&uid="+uid, {
		//		
		//		}, function(response){
		//			
		//			elm.replaceWith(response);
		//		
		//		});
		//});
		
		$('#addEvent').click(function(){
			
			var uid = <?=$user->uid;?>;
			var m = '<?=md5($user->uid."kyarata75");?>';
			var cid = <?=$_REQUEST['id'];?>;
			var event1 = $("#eventType").val();
			
			var loc = $("#eventLoc").val();
			var desc = $("#eventDesc").val();
			var datetime = $("#eventDate").val();
			
			var whyattend = $("#whyattend").val();
			var cost = $("#cost").val();
			var capacity = $("#capacity").val();
			//var addlink = $("#addlink").val();
			var tags = $("#tags").val();
			
			var invitees = $(".as-values").val();
			var uname = '<?=$user->name;?>';
			var urole = '<?=end($user->roles);?>';
			
			var files= [];
			
			$(".fileInfo").each(function () {
				var tmpArr = {'path':$(this).attr('path'),'title':$(this).attr('filetitle'),'timestamp':$(this).attr('timestamp')};
				files.push(tmpArr);
				});
			
			 
			$.post("<?php echo $base_url; ?>/themes/maennaco/includes/pro_posts.php?type=addEvent", { uid: uid, title: event1, loc: loc, desc:desc, date: datetime, whyattend: whyattend,cost:cost,capacity:capacity,tags:tags,u: uname, files: files,cid: cid,urole:urole},
				       
				       function(response){
					
					
					$('#posting').prepend($(response).fadeIn('slow'));
					
					$('.fileInfo').remove();
					
					$(".watermark").Watermark("Share ideas on this topic");
					
					/*$("#eventDate").val("When?");
					$("#eventType").val("TITLE");
					$("#eventLoc").val("WHERE?");
					$("#eventDesc").val("Agenda?");*/
					$("#eventType").val('');
					$("#eventLoc").val('');
					$("#eventDesc").val('');
					$("#eventDate").val('');
					
					$("#whyattend").val('');
					$("#cost").val('');
					$("#capacity").val('');
					//var addlink = $("#addlink").val();
					$("#tags").val('');
					
					/*$("#eventDate").Watermark("WHEN?");
					$("#eventType").Watermark("TITLE");
					$("#eventLoc").Watermark("WHERE?");
					$("#eventDesc").Watermark("AGENDA?");
					$("#cost").Watermark('COST');
					$("#capacity").Watermark('CAPACITY');
					
					$(".watermark").Watermark("watermark","#369");
					$("#eventDate").Watermark("watermark","#369");
					$("#eventType").Watermark("watermark","#369");
					$("#eventLoc").Watermark("watermark","#369");
					$("#eventDesc").Watermark("watermark","#369");
					$("#eventInv").Watermark("watermark","#369");*/
					
					//$("#eventFormDiv").hide("slow");
					location.reload();
					
					
			
				});

		});  
		
		$("#pro_cancel").click(function() {
			
			$("#eventFormDiv").hide("slow");
			$("#eventType").val('');
			$("#eventLoc").val('');
			$("#eventDesc").val('');
			$("#eventDate").val('');
			
			$("#whyattend").val('');
			$("#cost").val('');
			$("#capacity").val('');
			//var addlink = $("#addlink").val();
			$("#tags").val('');
			
			return false;
			});
		
		
		$('.watermark').livequery("focus", function(e){
		
			sbmBtt = $(this).attr('eventid');
			
			$('a[textref='+sbmBtt+']').show();		
		});
		
		//$('.watermark').livequery("focusout", function(e){
		//
		//	sbmBtt = $(this).attr('eventid');
		//	
		//	$('a[textref='+sbmBtt+']').hide('slow');		
		//});
		
		$('.commentMark').livequery("focus", function(e){
			
			var parent  = $('.commentMark').parent();			
			$(".commentBox").children(".CommentImg").hide();			
		
			var getID =  parent.attr('id').replace('record-','');			
			$("#commentBox-"+getID).children("a#SubmitComment").show();
			
			$("#commentBox-"+getID).children(".CommentImg").show();			
		});	
		
		//showCommentBox
		$('a.showCommentBox').livequery("click", function(e){
			
			var getpID =  $(this).attr('id').replace('post_id','');	
			
			$("#commentBox-"+getpID).css('display','');
			$("#commentMark-"+getpID).focus();
			$("#commentBox-"+getpID).children("CommentImg").show();			
			$("#commentBox-"+getpID).children("a#SubmitComment").show();		
		});	
		
		//SubmitComment
		$('a.comment').livequery("click", function(e){
			
			var getpID =  $(this).parent().attr('id').replace('commentBox-','');	
			var comment_text = encodeURIComponent($("#commentMark-"+getpID).val());
			var m = $(this).parent().attr("alt");
			var u = $(this).parent().attr("name");
                        var uid = '<?=$user->uid;?>';
			
			if(comment_text != "Got advice / question on this topic?")
			{
				$.post("<?php echo $base_url; ?>/themes/maennaco/includes/add_comment.php?u="+u+"&comment_text="+comment_text+"&post_id="+getpID+"&m="+m+"&uid="+uid, {
	
				}, function(response){
					
					$('#CommentPosted'+getpID).append($(response).fadeIn('slow'));
					$("#commentMark-"+getpID).val("Got advice / question on this topic?");
										
				});
			}
			
		});	
		
		//more records show
		$('a.more_records').livequery("click", function(e){
			
			var next =  $('a.more_records').attr('id').replace('more_','');
			
			$.post("<?php echo $base_url; ?>/themes/maennaco/includes/posts.php?show_more_post="+next, {

			}, function(response){
				$('#bottomMoreButton').remove();
				$('#posting').append($(response).fadeIn('slow'));

			});
			
		});	
		
		//deleteComment
		$('a.c_delete').livequery("click", function(e){
			
			if(confirm('Are you sure you want to delete this comment?')==false)

			return false;
	
			e.preventDefault();
			
			var c_id =  $(this).attr('id').replace('CID-','');	
			var u =  $(this).attr("name");
			var m =  $(this).attr("alt");
			
			$.ajax({

				type: 'get',

				url: '<?php echo $base_url; ?>/themes/maennaco/includes/delete_comment.php?c_id='+ c_id+"&u="+u+"&m="+m,

				data: '',

				beforeSend: function(){

				},

				success: function(){

						$('#comment-' + c_id).fadeOut(200,function(){
						
						$('#comment-' + c_id).remove();

					});
					
				}

			});
		});	
		
		/// hover show remove button
		$('.friends_area').livequery("mouseenter", function(e){
			$(this).children("label.name").children("a.delete").show();	
		});	
		$('.friends_area').livequery("mouseleave", function(e){
			$(this).children("label.name").children("a.delete").hide();	
		});
		
		$('.event').livequery("mouseenter", function(e){
			//$(this).children("span").children("a.delete").show();
			$(this).children("a.delete").show();	
		});	
		$('.event').livequery("mouseleave", function(e){
			//$(this).children("span").children("a.delete").hide();
			$(this).children("a.delete").hide();	
		});
		
		
		/// hover show remove button
		
		$('a.evdelete').livequery("click", function(e){

		if(confirm('Are you sure you want to delete this discussion?')==false)

		return false;

		e.preventDefault();
			

		var temp    = $(this).attr('id').replace('remove_id','');
		var u =  $(this).attr("name");
		var m =  $(this).attr("alt");
			
			$.ajax({ 

				type: 'get',

				url: '<?php echo $base_url; ?>/themes/maennaco/includes/delete.php?type=professional&id='+temp+"&u="+u+"&m="+m,

				data: '',

				beforeSend: function(){

				},

				success: function(){

					$('#event' + temp).fadeOut(200,function(){
						
						$('#event' + temp).remove();

					});
					
				}

			});
			return true;
			
		
		});
		
		
		
		$('a.delete').livequery("click", function(e){

		if(confirm('Are you sure you want to delete this post?')==false)

		return false;

		e.preventDefault();
			

		var parent  = $('a.delete').parent();

		var temp    = $(this).attr('id').replace('remove_id','');
		var u =  $(this).attr("name");
		var m =  $(this).attr("alt");
		
		var main_tr = $('#'+temp).parent();
		
		
		if ($(this).attr('delType') == 'event') {
			
			
			$.ajax({ 

				type: 'get',

				url: '<?php echo $base_url; ?>/themes/maennaco/includes/delete.php?type=event&id='+temp+"&u="+u+"&m="+m,

				data: '',

				beforeSend: function(){

				},

				success: function(){

					$('#event' + temp).fadeOut(200,function(){
						
						$('#event' + temp).remove();

					});
					
				}

			});
			return true;
			
			
		}
					
		$.ajax({ 

				type: 'get',

				url: '<?php echo $base_url; ?>/themes/maennaco/includes/delete.php?id='+temp+"&u="+u+"&m="+m,

				data: '',

				beforeSend: function(){

				},

				success: function(){

					$('#record-' + temp).fadeOut(200,function(){
						
						$('#record-' + temp).remove();

					});
					
				}

			});

		});

		$('textarea').elastic();

		jQuery(function($){

		   $(".watermark").Watermark("Share ideas on this topic");
		   $("#eventDate").Watermark("When?").addClass('watermark');;
		   //$("#eventType").Watermark("TITLE").addClass('watermark');;
		   $("#eventLoc").Watermark("Where?").addClass('watermark');;
		   $("#eventDesc").Watermark("Agenda?").addClass('watermark');;
		   $("#whyattend").Watermark("Why Attend").addClass('watermark');;
		   //$("#cost").Watermark("COST").addClass('watermark');;
		   $("#capacity").Watermark("Capacity").addClass('watermark');;
		   $("#eventInv").Watermark("+ Add people to notify");
		   $(".commentMark").Watermark("Got advice / question on this topic?");

		});

		jQuery(function($){

		   /*
		   $(".watermark").Watermark("watermark","#369");
		   $("#eventDate").Watermark("watermark","#369");
		   $("#eventType").Watermark("watermark","#369");
		   $("#eventLoc").Watermark("watermark","#369");
		   $("#eventDesc").Watermark("watermark","#369");
		   $("#eventInv").Watermark("watermark","#369");
		   $("#cost").Watermark("watermark","#369");
		   $("#capacity").Watermark("watermark","#369");
		   $("#whyattend").Watermark("watermark","#369");
		   $(".commentMark").Watermark("watermark","#EEEEEE");
		  */
		});	

		function UseData(){

		   $.Watermark.HideAll();

		   //Do Stuff

		   $.Watermark.ShowAll();

		}

	});	

	// ]]>

function showprodetails(id)
{
	$("#showpro"+id).show("slow");
}


function discussion(id, proid)
{
	
	window.location.href="./account?tab=professionals&page=pro_detail&id="+id+"&section=pro_industry_view&type=details&pro_id="+proid;
}

function like_discussion(type, prof_id, userid)
{
	
	if(type == 'like')
		var status = 1;
	else
		var status = 0;
	
	$.ajax({ 

				type: 'get',

				url: '<?php echo $base_url; ?>/themes/maennaco/includes/delete.php?type=like_discussion&prof_id='+prof_id+'&userid='+userid+'&status='+status,

				data: '',

				beforeSend: function(){

				},

				success: function(){

								location.reload();
								/*if(type == 'like')
								{
									$('#likepost').html("<a style='cursor:pointer;' onclick='like_discussion(\"unlike\", "+prof_id+","+userid+");'>Unlike</a>");
								}
								else
								{
									$('#likepost').html("<a style='cursor:pointer;' onclick='like_discussion(\"like\", "+prof_id+","+userid+");'>Like</a>");
								}*/
					
				}

			});
}
function isNumberKey(evt)
{
  var charCode = (evt.which) ? evt.which : event.keyCode;
  if (charCode != 46 && charCode > 31 
	&& (charCode < 48 || charCode > 57))
	 return false;

  return true;
}

</script>

	<div> <!--align="center"--> 
	<?php /*if ($_REQUEST['id'] == $user->uid || end($user->roles) == 'Super admin' || end($user->roles) == 'Maennaco admin') { */
	
		//if ($AccessObj->Com_sections['discussions']['sections']['nav_menu_right']['access'] == 'write') {
	?>
	
		<!--<a id="showEventForm" class = "small button" style=" font-size:12px;float:right; margin-top:10px;">SCHEDULE A DISCUSSION</a>-->
		
		<div id="eveditdlg"></div>
		<div id="profiledlg"></div>
		<div style="clear:both;"></div>
		<div id="eventFormDiv" style="display:none;" >
		<form action ="" method = "post" name="addEvent" id="addEventForm">
        <div class="dischead">
        	<div class="dtitle">schedule discussion</div>
           <!-- <div class="dedit"><a href='#'>ATTACH FILE</a></div><div style="clear:both"></div>-->
		    <div class="dedit"><!--<a href='#'>--><a style="float:right; margin-left:10px;" href="#" id="file_id<?php  echo $row1['id']?>" alt="<?php  echo md5($row1['id'].$user->name."kyarata75") ?>" name="<?=$user->name;?>" delType = 'event' class="tool file" title="Add materials: Files / Links"><img src="<?php echo $base_url; ?>/themes/maennaco/images/upload_bk.png"></a></div><div style="clear:both"></div>
        </div>
			
			<input class="discuss" id="eventType" placeholder="Title" name="eventType" type="text" />
            <!--<textarea class="input" id="eventType" name="eventType" cols="60" placeholder="TITLE" ></textarea>-->
			<input class="input" id="eventLoc" placeholder="Where?" name="eventLoc" cols="20">
			<input type='text' id="eventDate" placeholder="When?" name="eventDate" class='datepicker' style="15px/160% Verdana, sans-serif;" /><br>
			
			<script type='text/javascript'>
				$(function() {
					$("#eventDate").datetimepicker({dateFormat: 'yy-mm-dd'});
					$("#test").datetimepicker({dateFormat: 'yy-mm-dd'});
						var uploader = new qq.FileUploader({
							// pass the dom node (ex. $(selector)[0] for jQuery users)
							element: $("#file-uploader")[0],
							// path to server-side upload script
							action: '/themes/maennaco/includes/file_upload.php',
							onComplete: function(id, fileName, responseJSON){
								
								if (responseJSON['success']) {
								$("#eventType").before('<input type="hidden" class="fileInfo" path="'+fileName+'" filetitle="'+$("#fileTitle").val()+'" timestamp = "'+responseJSON['timestamp']+'">');
								$("#fileTitle").val('');
								
								}
								
							}
						}); 
					});
            </script>
			<textarea class="input" id="eventDesc" placeholder="Agenda" name="eventDesc"cols="60" style="height:95px;"></textarea><br>
			<textarea class="input" id="whyattend" placeholder="Why Attend?" name="whyattend" cols="60"></textarea><br>
			<input  class="input" type='text' placeholder="Cost" id="cost" name="cost" />
			<input  class="input" type='text' placeholder="Capacity" id="capacity" onkeypress="return isNumberKey(event)" name="capacity" />
            <!--<input  class="input" type='text' placeholder="ADD LINK" id="link" onkeypress="return isNumberKey(event)" name="link" style="width:207px!important;" />
			
			
			<div id="tags">-->
			<select class="discuss" id="tags" name="tags">
			<option>Choose a Category</option>
			<option value="Customers">Customers</option>
			<option value="Employees">Employees</option>
			<option value="Products">Products</option>
			<option value="Moat">Moat</option>
			<option value="Pricing">Pricing</option>
			<option value="Market">Market</option>
			<option value="Competition">Competition</option>
			<option value="Plan">Plan</option>
			<option value="Priorities">Priorities</option>
			<option value="Metrics">Metrics</option>
			<option value="Financials">Financials</option>
			<option value="Risks">Risks</option>
			<option value="Opportunities">Opportunities</option>
			</select>
			<!--</div>--><br>
			
			<!--<textarea class="input" id="eventInv" name="eventInv" style="height:20px" cols="60"></textarea><br>-->
			
			<div id='evFile' style='text-align:left; display:none'>
               <input style="background:none;float:left;border:solid 2px #DCE6F5;" type=text id="fileTitle" />
              <div id="file-uploader">
				<noscript>
				    <p>Please enable JavaScript to use file uploader.</p>
				    <!-- or put a simple form for upload here -->
				</noscript>
				
			    </div>
                        <!--<a style="pointer:cursor; float:left; padding:0;" class='hidebox button' boxid=evFile>CLOSE</a>-->
			    <div style="clear:both"></div>
                    </div>
			<?=js_init("init_openbox();init_hidebox();");?>
			
            <div class="diss">
            	
				<input type="button" id="addEvent" class="small button" value="Submit" />
                <input type="submit" class="small button" value="Cancel" id="pro_cancel" />
<!--				<a class="small button"> CANCEL </a>
				<a id="addEvent" class="small button"> SUBMIT </a>
-->	
			</div>
			<!--
			<br><hr style="color: #E7E6E7;background-color: #E7E6E7;height: 5px;">
			<br>-->

			
		</form>
		</div>
<?php //} ?>	

		<div id="posting" align="left">
		<input id="attSpan" type="hidden" value="">
	
		<?php

		
		
		//require('pro_comments_list.php');
		
		?>
	
	
	
		    
<?php
$page = sget($_REQUEST, 'page');
	$type = sget($_REQUEST, 'type');
	$id = sget($_REQUEST, 'id');
	



$sql_result = "SELECT * FROM  `maenna_professional` WHERE postedby =" . $id;

if($_REQUEST['sort'] != '')
{
	$sql_result .=" AND `tags` LIKE '%" . $_REQUEST['sort'] . "%'"; 	
}

if($_REQUEST['sortmonth'] != '')
{
	$sql_result .=" AND MONTH(FROM_UNIXTIME(datetime)) = " . $_REQUEST['sortmonth']; 	
}

if($_REQUEST['sortdate'] != '')
{
	$sql_result .=" AND datetime = " . $_REQUEST['sortdate']; 	
}

$sql_result .= " ORDER BY id DESC";


$result1 = mysql_query ($sql_result);

		  while ($row1 = mysql_fetch_array($result1)) {
		  
		  
		  $sql_expertise = mysql_query ("SELECT * FROM  `maenna_people` WHERE `pid` = '" .$row1['postedby'] ."'");
			$sql_exp_result = mysql_fetch_array($sql_expertise);
			$P_username = ucfirst($sql_exp_result['firstname']) . ' ' . ucfirst($sql_exp_result['lastname']);
			
			if($sql_exp_result['firstname'] == '')
				$P_username = 'Super_admin';
			else
				$P_username = $P_username;
			
			
		  
		  $sql_likes = mysql_query ("SELECT * FROM  `like_discussion_professional` WHERE `user_id` = '" . $id."' AND `prof_id` = '" . $row1['id']."' ORDER BY id DESC");
		  $sql_likes_result = mysql_num_rows($sql_likes);
		  
		  $sql_remaining_spots = mysql_query("SELECT * FROM  `maenna_professional_payments` WHERE `user_id` = '" . $id."' AND `pro_id` = '" . $row1['id']."' ORDER BY id DESC");
		  $sql_remaining_spots_count = mysql_num_rows($sql_remaining_spots);
$result3 = mysql_query ("SELECT * 
					     FROM  `like_discussion_professional` 
					     WHERE  prof_id = '".$row1['id']."' and user_id = '".$id."'");

$likepost = mysql_num_rows($result3);
$likepostArray = mysql_fetch_array($result3);



?>
		 
		 <div class="event" id="event<?=$row1['id'];?>">

</span>
	 <div id="clear" style="clear:both"></div>
		  <div style="float:left;" class="calendar">
			   <span class="day"><?=date("d",$row1['datetime']);?></span>
			   <span class="month"><?=strtoupper(date("M",$row1['datetime']));?></span>
			   <?php
			   		if($row1['cost'] == 0)
					{
						echo "<p>FREE</p>";
					}
			   ?>
		  </div><!-- calendar -->
		 
		  <div class="event-info">
                       <div style="margin-left:10px; float:left; width:525px;">
			   <a onclick="discussion('<?=$id?>', '<?=$row1['id']?>');" href="<?php echo $base_url; ?>/account?tab=professionals&page=pro_detail&id=<?=$id?>&section=pro_industry_view&type=details&pro_id=<?=$row1['id']?>"><span class="eventTitle" style="float:left; cursor:pointer;"><strong><?=replace_email(strtoupper(substr($row1['title'],0,40)));?><?php if(strlen($row1['title']) > 40) { ?>...<?php } ?></strong></span></a>
               <span style="float:right; padding:0px; margin:-3px 0px 0px 0px; font-size:12px; color:#76787f; font-weight:bold; font-family:'Lato Regular';">
			   <?php if($likepost == 1 && $id == $likepostArray['user_id']) { ?>
			   	<span id="likepost"><a style="cursor:pointer; color:#00A3BF;" onclick="like_discussion('unlike', '<?=$row1['id']?>','<?=$id?>');">Unlike</a></span>
			   <?php } else {?>
			   <span id="likepost"><a style="cursor:pointer;color:#00A3BF;" onclick="like_discussion('like', '<?=$row1['id']?>','<?=$id?>');">Like</a></span>
			<?php } ?>
			   
			    <?php echo ($sql_likes_result != '0') ? $sql_likes_result : '0'; ?></span>
               <div id="clear" style="clear:both"></div>
			   <span class="prodatetime"><?=date("l, M j, Y g:i A T ",$row1['datetime']);?></span>
               <span style="float:right; padding:0px; margin:-8px 0px 0px 0px; font-size:12px; color:#76787f; font-weight:bold; font-family:'Lato Regular';">Spots Left
			   

			   <?php 
			    	
						echo $row1['spots'];
				?>
			   </span>
			   <div id="clear" style="clear:both"></div>
			   <div style=" margin:5px 0px 0px 0px;">
			   <span class="profile_info">
			   
			   <a href="#" id="edit_id<?php echo $row1['id'];?>" class="profile_details" name="<?=$user->name;?>"><?php echo $P_username; ?></a>,
			   <span>
			   <?php /*?><?=$row1['tags']?><?php */?>
			   <?php 
			   	if(!empty($sql_exp_result)) {
			    	echo preg_replace('/(?<! )(?<!^)[A-Z]/',' $0', $sql_exp_result['experties']);
				}
				?>
			   </span></span>
			   
			   </div>
			   <div id="clear" style="clear:both"></div>
			   
			   <span style="float:left; margin:5px 0px 0px 0px; text-align:left;"><?=substr($row1['description'], 0, 160);?>...<a onclick="discussion('<?=$id?>', '<?=$row1['id']?>', '<?=$row1['title']?>');" href="<?php echo $base_url; ?>/account?tab=professionals&page=pro_detail&id=<?=$id?>&section=pro_industry_view&type=details&pro_id=<?=$row1['id']?>" class="tool">More</a></span><div id="clear" style="clear:both"></div>
			     <span style="float:left; display:none;"><?=$row1['description'];?></span>
				   <div id="clear" style="clear:both"></div>
				  <?php
	 if($row1['postedby'] == $user->uid || $AccessObj->Com_sections['discussions']['sections']['maenna_events']['access'] == 'write'){?>
	 		<span class='discussion_span_edit'>
		  	
			<a style="float:left;margin-top:10px; padding:0px 7px 0px 7px; border-right:1px solid #76787f; border-left:1px solid #76787f; line-height:12px;" href="#" id="edit_id<?php  echo $row1['id']?>" alt="<?php  echo md5($row1['id'].$user->name."kyarata75") ?>" name="<?=$user->name;?>" delType = 'event' class="tool evedit"><strong>Edit</strong></a>

			
			<a style="float:left;margin-top:10px; padding:0px 7px 0px 7px;line-height:12px;" href="#" id="remove_id<?php  echo $row1['id']?>" alt="<?php  echo md5($row1['id'].$user->name."kyarata75") ?>" name="<?=$user->name;?>" delType = 'event' class="tool evdelete"> <strong>Delete</strong></a>
	<?php } ?>		
			
			</span>
			    
			   </div>
			   
				    <span class="attFiles" style="float:left;font-size:10px;">
			   
			   </span>
			   </div>
			   
			
			
</div> 
			
			  <div id="clear" style="clear:both"></div> <br />
			  <?php /*?><div id="showpro<?=$row1['id']?>" style="display:none; height: 215px;">
			 <div class="dischead" style="padding: 5px 0 5px 7px; height:20px;">
        	<div class="dtitle">TITLE OF DISCUSSION</div><br /><br />
			<span><strong>Professional Name</strong>, Expertise</span><br /><br />
			
			<span><a style="cursor:pointer;" onclick="showabout();">About</a></span>&nbsp;&nbsp;<span><a style="cursor:pointer;" onclick="showabout();">Conversation</a></span><br /><br />
			<span>Agenda</span>
			<span style="float:left; display:none"><?=$row1['description'];?></span>
			
        	</div>
			</div><?php */?>
			   <?php } ?>
		  
	
	
		  
		</div>


	</div>
	</div>