<?php
error_reporting(0);
global $base_url;
global $user;
$user_id = $user->uid;
include('dbcon.php');
// find out the domain:
$domain = $_SERVER['HTTP_HOST'];
// find out the path to the current file:
$path = $_SERVER['SCRIPT_NAME'];
// find out the QueryString:
$queryString = $_SERVER['QUERY_STRING'];
// put it all together:
$paymenturl1= "http://" . $domain . $path . "?" . $queryString;
//echo "The current URL is: " . $url . "";
 
// An alternative way is to use REQUEST_URI instead of both
// SCRIPT_NAME and QUERY_STRING, if you don't need them seperate:
$paymentur2 = "http://" . $domain . $_SERVER['REQUEST_URI'];
//echo "The alternative way: " . $url2;
$id = $_REQUEST['id'];

$uname = $user->name;

$user_id = $user->uid;

if($_POST['post_comment'] != '')
{
	mysql_query("INSERT INTO pro_wall_posts_comments (d_id,post_id,user_id,comment,username,datecreated) VALUES('".$_REQUEST['dis_id']."','".$_REQUEST['post_id']."','".$user_id."','".checkValues($_REQUEST['post_comment'])."','".$uname."','".strtotime(date("Y-m-d H:i:s"))."')");
	
	$ins_id = mysql_insert_id();
	
	$url = $base_url."/account?tab=professionals&page=pro_detail&id=".$id."&section=pro_industry_view&type=details&tabs=2&pro_id=".$_REQUEST['dis_id']."#com".$ins_id."";
	header("location:".$url."");
	exit;
}

if($_POST['dis_posts'] != '')
{
	
	mysql_query("INSERT INTO pro_wall_posts (pro_id,post,f_name,user,tags,flag,date_created) VALUES('".$_POST['prof_id']."','".checkValues($_REQUEST['dis_posts'])."','".$uname."','".$uname."','". $_REQUEST['tags']."','" . $_REQUEST['flag'] . "','".strtotime(date("Y-m-d H:i:s"))."')");
	
	$ins_id = mysql_insert_id();
	
	$url = $base_url."/account?tab=professionals&page=pro_detail&id=".$id."&section=pro_industry_view&type=details&tabs=2&pro_id=".$_REQUEST['prof_id']."&post_id=" . $ins_id . "#dis_post".$ins_id."";
	header("location:".$url."");
	exit;
	
}
if($_POST['payment_status'] == "Completed")
{
	mysql_query("INSERT INTO maenna_professional_payments (pro_id,transaction_id,user_id,amount,status,date_created) VALUES('".$_REQUEST['pro_id']."','".$_POST['txn_id']."','".$user_id."','".$_POST['mc_gross']."','1','".strtotime(date("Y-m-d H:i:s"))."')");	
	header("location:".$paymenturl1."");
	exit;	
}



function checkValues($value)
	{
		 // Use this function on all those values where you want to check for both sql injection and cross site scripting
		 //Trim the value
		 $value = trim($value);
		 
		// Stripslashes
		if (get_magic_quotes_gpc()) {
			$value = stripslashes($value);
		}
		
		 // Convert all &lt;, &gt; etc. to normal html and then strip these
		 $value = strtr($value,array_flip(get_html_translation_table(HTML_ENTITIES)));
		
		 // Strip HTML Tags
		 $value = strip_tags($value);
		
		// Quote the value
		$value = mysql_real_escape_string($value);
		$value = htmlspecialchars ($value);
		return $value;
		
	}	

?>
<script type="text/javascript" src="<?php echo $base_url; ?>/themes/maennaco/jui/comments/js/jquery.livequery.js"></script>
<script type="text/javascript" src="<?php echo $base_url; ?>/themes/maennaco/jui/comments/js/jquery-ui-timepicker-addon.js"></script>

<script type="text/javascript" src="<?php echo $base_url; ?>/themes/maennaco/jui/comments/js/jquery.autosuggest.js"></script>
<link href="<?php echo $base_url; ?>/themes/maennaco/jui/comments/css/screen.css?as" type="text/css" rel="stylesheet" />
<link href="<?php echo $base_url; ?>/themes/maennaco/jui/comments/css/autosuggest.css" type="text/css" rel="stylesheet" />
<link href="<?php echo $base_url; ?>/themes/maennaco/jui/comments/css/fileuploader.css" type="text/css" rel="stylesheet" />
<link href="<?php echo $base_url; ?>/themes/maennaco/jui/comments/css/SpryTabbedPanels.css" type="text/css" rel="stylesheet" />

<script src="<?php echo $base_url; ?>/themes/maennaco/jui/comments/js/jquery.elastic.js" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo $base_url; ?>/themes/maennaco/jui/comments/js/fileuploader.js" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo $base_url; ?>/themes/maennaco/jui/comments/js/jquery.watermarkinput.js" type="text/javascript"></script>
<script src="<?php echo $base_url; ?>/themes/maennaco/jui/comments/js/SpryTabbedPanels.js" type="text/javascript"></script>

<script type="text/javascript">

<?php if($_REQUEST['tabs'] == 2) { ?>
$(document).ready(function(){
	$('#tab2').trigger('click');
});
<?php } ?>
$( "#dialog" ).dialog({
			autoOpen: false
		    });
		
		$("#join").livequery("click",function (e) {
			
			e.preventDefault();
			
			//var createaccount = $("#createaccount").show();
		
				
				
				$( "#createaccount" ).dialog({
                                        autoOpen: true,
                                        width: 450,
                                        title: 'CREATE AN ACCOUNT',
                                        height:300,
                                        closeOnEscape: true,
                                        modal:true
                                    }).html();

				
				
				
				
						
		});
		
		

$('[id^=shareButton]').livequery("click", function(){
			
			tarea = $('textarea[proid='+$(this).attr('textref')+']');
			var a = encodeURIComponent(tarea.val());
			var m =  tarea.attr("alt");
			var u =  tarea.attr("name");
			var prof_id =  $("#pro_id").val();
            var uid = '<?=$user->uid;?>';
			var proid = tarea.attr('proid');
			
			

			if(a != "Discuss a topic or ask a question on this file ...")
			{
			 
				$.post("<?php echo $base_url; ?>/themes/maennaco/includes/pro_comments_list.php?type=pro_comments&prof_id="+prof_id+"&u="+u+"&m="+m+"&value="+a+"&proid="+proid+"&uid="+uid, {
			
				}, function(response){
					
					tarea.parent().parent().parent().parent().after($(response).fadeIn('slow'));
					tarea.val("Share ideas on this topic");
					
					$('textarea').elastic();
					$(".commentMark").Watermark("Got advice / question on this topic?");
					tarea.Watermark("watermark","#369");
					
					$(".commentMark").Watermark("watermark","#EEEEEE");
			
				});
			}
		});
$('textarea').elastic();

function to_join()
{

			$( "#payment" ).dialog({
									autoOpen: true,
									width: 450,
									title: 'PROCEED WITH PAYMENT',
									height:300,
									buttons: { 
	"Cancel": function() { $(this).dialog("close"); }
	}, closeOnEscape: true,
	modal:true
	}).show;	

}

function showsubmit(id)
{

$('#post_com'+id).show();

}
function submitcomment(id)
{
	$.post("<?php echo $base_url; ?>/themes/maennaco/includes/pro_comments_list.php?type=pro_comments&prof_id="+prof_id+"&u="+u+"&m="+m+"&value="+a+"&proid="+proid+"&uid="+uid, {
			
				}, function(response){
					
					
			
				});
}


		
		$('.deletepost').livequery("click", function(e){

		if(confirm('Are you sure you want to delete this Post?')==false)

		return false;

		e.preventDefault();
			

		var temp    = $(this).attr('id').replace('deletepost','');
		
			
			$.ajax({ 

				type: 'get',

				url: '<?php echo $base_url; ?>/themes/maennaco/includes/delete.php?type=professional_post&id='+temp,

				data: '',

				beforeSend: function(){

				},

				success: function(){

					$('#dis_post' + temp).fadeOut(200,function(){
						
						$('#dis_post' + temp).remove();

					});
					
				}

			});
			return true;
			
		
		});

		$('.delete_comment').livequery("click", function(e){

		if(confirm('Are you sure you want to delete this Post?')==false)

		return false;

		e.preventDefault();
			

			var temp    = $(this).attr('id').replace('delete_comment','');
		
			
			$.ajax({ 

				type: 'get',

				url: '<?php echo $base_url; ?>/themes/maennaco/includes/delete.php?type=professional_comments&id='+temp,

				data: '',

				beforeSend: function(){

				},
				success: function(){

					location.reload();
					/*$('#dis_post' + temp).fadeOut(200,function(){
						
						$('#dis_post' + temp).remove();

					});*/
					
				}

			});
			return true;
			
		
		});

function like_discussion(type, prof_id, userid)
{
	
	if(type == 'like')
		var status = 1;
	else
		var status = 0;
	
	$.ajax({ 

				type: 'get',

				url: '<?php echo $base_url; ?>/themes/maennaco/includes/delete.php?type=like_discussion&prof_id='+prof_id+'&userid='+userid+'&status='+status,

				data: '',

				beforeSend: function(){

				},

				success: function(){

								if(type == 'like')
								{
									$('#likepost').html("<a style='cursor:pointer;' onclick='like_discussion(\"unlike\", "+prof_id+","+userid+");'>Unlike</a>");
								}
								else
								{
									$('#likepost').html("<a style='cursor:pointer;' onclick='like_discussion(\"like\", "+prof_id+","+userid+");'>Like</a>");
								}
					
				}

			});
}


function like_posts(type, prof_id, post_id, userid)
{
	if(type == 'like')
		var status = 1;
	else
		var status = 0;
	
	$.ajax({ 

				type: 'get',

				url: '<?php echo $base_url; ?>/themes/maennaco/includes/delete.php?type=like_posts&prof_id='+prof_id+'&post_id='+post_id+'&userid='+userid+'&status='+status,

				data: '',

				beforeSend: function(){

				},

				success: function(){

								if(type == 'like')
								{
									//$('#likepost1'+post_id).html("<a style='cursor:pointer;' onclick='like_posts(\"unlike\", "+prof_id+", "+post_id+","+userid+");'>Unlike</a>");
									location.reload();
								}
								else
								{
									//$('#likepost1'+post_id).html("<a style='cursor:pointer;' onclick='like_posts(\"like\", "+prof_id+", "+post_id+","+userid+");'>Like</a>");
									location.reload();
								}
					
				}

			});
}


function joinnow2(pro_id, id)
{
			
		$.post("<?php echo $base_url; ?>/themes/maennaco/includes/delete.php?type=join&prof_id="+pro_id+"&uid="+id, {
			
				}, function(response){
					
					location.reload();
			
				});			
}

function validate_minutes()
{
	if($('#dis_posts').val() == '')
	{
		alert('Content field is required');
		return false;
	}else if($('#tags').val() == '')
	{
		alert('Categories field is required');
		return false;
	}
}

function validate_questions()
{
	if($('#dis_posts_question').val() == '')
	{
		alert('Please type your question.');
		return false;
	}else if($('#tags_question').val() == '')
	{
		alert('Categories field is required');
		return false;
	}
}

function show_minutes()
{
	$('#question').hide();
	$('#minutes').show();
}

function ask_question()
{
	$('#minutes').hide();
	$('#question').show();
}

function formDisplay(id)
{
	$('#form_id'+id).show();
}
function show_files(id,proid, file)
{			
	window.location.href="./account?tab=professionals&page=pro_detail&id="+id+"&section=pro_industry_view&type=details&tabs=1&pro_id="+proid+"&files="+file;
}

function like_post_comments(type, comment_id, user_id)
{
	if(type == 'like')
		var status = 1;
	else
		var status = 0;
	
	$.ajax({
				type: 'get',
				url: '<?php echo $base_url; ?>/themes/maennaco/includes/delete.php?type=like_post_comments&comment_id='+comment_id+'&user_id='+user_id+'&status='+status,
				data: '',
				beforeSend: function(){	},
				success: function(){
					if(type == 'like')
					{
						$('#likepostcomment'+comment_id).html("<a style='cursor:pointer;' onclick='like_post_comments(\"unlike\", "+comment_id+","+user_id+");'>Unlike</a>");
					}
					else
					{
						$('#likepostcomment'+comment_id).html("<a style='cursor:pointer;' onclick='like_post_comments(\"like\", "+comment_id+","+user_id+");'>Like</a>");
					}					
				}
			});
}
</script>

<style type="text/css">
div.content_box .box_title {
margin-top:14px;
}
</style>
<?php
	function nameToId($name) {

	$q = mysql_query("SELECT uid FROM users WHERE name = '".$name."' LIMIT 1") or die(mysql_error());
	$r = mysql_fetch_array($q);
	return $r['uid'];

	}

	function getUserType($uid) {

	$q = mysql_query("SELECT pid FROM maenna_people WHERE pid = '".$uid."' ");

	if (mysql_num_rows($q) > 0 ) return 'people';

	else {
		$q1 = mysql_query("SELECT companyid FROM maenna_company WHERE companyid = '".$uid."' ");
		if (mysql_num_rows($q1) > 0 ) return 'company';
		else return 'admin';
		}
}

	$page = sget($_REQUEST, 'page');
	$type = sget($_REQUEST, 'type');
	$id = sget($_REQUEST, 'id');
	$pro_id = sget($_REQUEST, 'pro_id');
$result1 = mysql_query ("SELECT * 
					     FROM  `maenna_professional` 
					     WHERE  id = '".$pro_id."' ORDER BY id DESC ");
$row1 = mysql_fetch_array($result1);


$result3 = mysql_query ("SELECT * 
					     FROM  `like_discussion_professional` 
					     WHERE  prof_id = '".$pro_id."' and user_id = '".$id."'");

$likepost = mysql_num_rows($result3);
$row3 = mysql_fetch_array($result3);

$resPayment = mysql_query ("SELECT * FROM  `maenna_professional_payments` WHERE  pro_id = '".$pro_id."' and user_id = '".$user_id."' ");
$checkUserCount = mysql_num_rows($resPayment);
$checkUser = mysql_fetch_array($resPayment);


$sql_expertise = mysql_query ("SELECT * FROM  `maenna_people` WHERE `pid` = '" .$row1['postedby'] ."'");
$sql_exp_result = mysql_fetch_array($sql_expertise);
$P_username = ucfirst($sql_exp_result['firstname']) . ' ' . ucfirst($sql_exp_result['lastname']);

$cost = $row1['cost'];

?>
<div id='docprev' style="width:600px;">
<div>
	<div class="join">
	
	<div class="jleft">
	<a href="#" class='discussion_link'><?=date("l, M j, Y g:i A T ",$row1['datetime']);?></a><div style="clear:both"></div>
	
	<?php echo $P_username; ?>, <span><?php echo $sql_exp_result['experties']; ?></span>		
    </div>
	</div>
	
	<div class="jrght">
	<!--<form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">-->	
	 <form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post"> 
    <input type="hidden" name="cmd" value="_xclick">
   <input type="hidden" name="business" value="mostur_1361965395_per@live.com">
    <input type="hidden" name="item_name" value="Donation">
    <input type="hidden" name="item_number" value="1">
    <input type="hidden" name="amount" value="<?php echo $row1['cost']; ?>.00">
    <input type="hidden" name="no_shipping" value="0">
    <input type="hidden" name="no_note" value="1">
    <input type="hidden" name="currency_code" value="USD">
    <input type="hidden" name="lc" value="AU">
	<INPUT TYPE="hidden" NAME="return" value="<?php echo $paymenturl1;?>">
    <!--<input type="hidden" name="bn" value="PP-BuyNowBF">-->
	<input type="hidden" name="hosted_button_id" value="58JBKVTL2D9JW">
	<input type="hidden" name="rm" value="2">
	</form>
   <!-- <input type="image" src="https://www.paypal.com/en_AU/i/btn/btn_buynow_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online.">-->
	
 	<?php /*?>if($checkUserCount <= 0) { 
	if($row1['postedby'] != $_REQUEST['id']) {
		if($row1['cost'] != 0) { ?>
			<input type="button" id="joinnow" onclick="to_join();" class="small button" value="JOIN">
<?php 
		} else { ?>
	<input type="button" onclick="joinnow2('<?php echo $pro_id; ?>','<?php echo $id; ?>');" class="small button" value="JOIN">
	<?php } } } ?>
	<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">   
	</form>
	
	<span><?php echo ($row1['cost'] != '') ? '$' .number_format($row1['cost']) : '$0.00'; ?></span><?php */?>
	
	<br /><br /><br />
            
	<div id="TabbedPanels1" class="TabbedPanels">

			
 	 	<ul class="TabbedPanelsTabGroup">
			<li class="TabbedPanelsTab" id="tab1" tabindex="0">About</li>
			<li class="TabbedPanelsTab" id="tab2" tabindex="0">Conversations</li>
	   </ul>
	   
		
		<div class="TabbedPanelsContentGroup">
		
<!--- start about tab content -->

		<div class="TabbedPanelsContent">
		<div style="float: left;padding: 15px;width:569px;">
		<strong style="font-weight:bold; color:#333333;">Agenda</strong>
		<p><?=$row1['description'];?></p> 
		<strong style="font-weight:bold; color:#333333;">Why Attend?</strong>
		<p><?=$row1['whyattend'];?></p>
		</div>


		<div class="materials">
			<strong style="font-weight:bold; color:#333333; margin-left:10px;">Materials</strong><br />
<!--			<strong>FILES :</strong>
-->			<?php 
				//Getting images and links of event.
				$sql_images = mysql_query ("SELECT * FROM maenna_professional_file WHERE professional_id = '".$_REQUEST['pro_id']."'");
	 
				//$images = mysql_fetch_array($sql_images);
				
					echo "<ul>";
					
					while ($images = mysql_fetch_assoc($sql_images)) {
					
						if($images['file_name'] != '') {
							
							list($time_stamp, $file_name) = explode('_', $images['file_name']);
							list($name, $ext) = explode('.',$file_name);
							
							if($checkUser['status'] == 1 OR $row1['postedby'] == $user_id)
							{
								$id = $_REQUEST['id'];
								$pro_id = $_REQUEST['pro_id'];
								$file_name = $images['file_name'];
								echo '<li>'; ?>
								
								<a onClick="show_files('<?php echo $id; ?>', '<?php echo $pro_id; ?>', '<?php echo $file_name; ?>')" href="javascript:void(0);"><?php echo $name; ?></a>
								
								<?php echo '</li>';
							}else 
							{ 
								echo '<li>'
								
								. $name. '</li>';
							}
						}
					}
					echo "</ul>";
				?>
				<?php if($_REQUEST['files'] != '') { ?>
				<?php 
				 list($time_stamp, $file_name) = explode('_', $_REQUEST['files']);
				 list($name, $ext) = explode('.',$file_name);
				 echo '<p style="text-align:center !important;margin-right: 128px;">' . $name . '</p>';
				?>
		  <iframe src="http://docs.google.com/viewer?url=<?php echo $base_url; ?>/sites/default/files/events_tmp/<?php echo $_REQUEST['files']; ?>&embedded=true" width="600" height="670" style="border: none;"></iframe>
		  <?php } ?>
			

<!--			<strong>LINKS :</strong>
-->			<?php 
				//Getting images and links of event.
				$sql_links = mysql_query ("SELECT * FROM  maenna_professional_links WHERE professional_id = '".$_REQUEST['pro_id']."'");
	 
				while ($links = mysql_fetch_assoc($sql_links)) {
				//echo $row1['cost'] ."!=". 0;
				
				if($checkUser['status'] == 1 OR $row1['postedby'] == $user_id)
				{
							
							echo "<ul>";
					
					if($links['links'] != '') {
						
					$st = strpos($links['links'],"://");
					if($st == 0)
					{
						$resc = "http://".trim($links['links']);
					}
					else 
					{
					$resc = $links['links'];
					}
						
						echo '<li><a target="_blank" href="' . $resc . '">' . $links['name'] . '</a></li>';
					}
					echo "</ul>";
				
				
				
				}else {
				
					echo "<ul>";
					echo '<li>' . $links['name'] . '</li>';
					echo "</ul>";
				}
			}
			?>
		</div>
		</div>
		
<!--- end about tab content -->		

<!--- start conversation tab content -->
<?php

// if(!empty($checkUser) && ($checkUser['status'] == 1 || $checkUser['amount'] == 0) || $row1['postedby'] == $user_id )

 if(!empty($checkUser) && $checkUser['status'] == 1 || $row1['postedby'] == $user_id )
 { ?>
		
		<div class="TabbedPanelsContent">
		 <span style="margin-right:0px" class="add_minutes_span">
		<?php if($row1['postedby'] == $user_id) { ?>
		<a href="javascript:void(0);" onClick="show_minutes();">Add Minutes</a>
		 | <?php } ?><a href="javascript:void(0);" onClick="ask_question();">Ask a question</a></span><div style="clear:both"></div>
		
			<div class="tabtags">
			<div class="comts">
			 
			
			<div id="minutes" class="conversations_forms" style="display:none;">
			<div id="error"></div>
			<form method="post" action="<?php echo $base_url; ?>/account?tab=professionals&page=pro_detail&id=<?php echo $id; ?>&section=pro_industry_view&type=details&pro_id=<?=$row1['id']?>" id="comments">
			<input type="hidden" name="prof_id" id="prof_id" value="<?php echo $row1['id']; ?>"  />
			<input type="hidden" name="dis_id" id="dis_id" value="<?php echo $id; ?>"  />
			<input type="hidden" name="flag" id="flag" value="m"  />
			<table width="100%" id="minutues">
				<tr>
					<td><textarea name="dis_posts" placeholder="Content" id="dis_posts" cols="52" rows="7"></textarea></td>
				</tr>
				<tr>
					<td>
						<select id="tags" name="tags">
						<option value="">Choose a Category</option>
						<option value="Customers">Customers</option>
						<option value="Employees">Employees</option>
						<option value="Products">Products</option>
						<option value="Moat">Moat</option>
						<option value="Pricing">Pricing</option>
						<option value="Market">Market</option>
						<option value="Competition">Competition</option>
						<option value="Plan">Plan</option>
						<option value="Priorities">Priorities</option>
						<option value="Metrics">Metrics</option>
						<option value="Financials">Financials</option>
						<option value="Risks">Risks</option>
						<option value="Opportunities">Opportunities</option>
						</select>
					</td>
				</tr>
				<tr>
					<td><input type="submit" name="dis_post" onClick="return validate_minutes();" value="Submit" class="tool" /> <input type="submit" name="dis_post" id="cancel" value="Cancel" onClick="javascript:$('#minutes').hide();return false;" class="tool" /></td>
				</tr>
				</table>
			</form>
			</div>
			<div id="question" class="conversations_forms" style="display:none;">
			<form method="post" action="<?php echo $base_url; ?>/account?tab=professionals&page=pro_detail&id=<?php echo $id; ?>&section=pro_industry_view&type=details&pro_id=<?=$row1['id']?>" id="comments">
			<input type="hidden" name="prof_id" id="prof_id" value="<?php echo $row1['id']; ?>"  />
			<input type="hidden" name="dis_id" id="dis_id" value="<?php echo $id; ?>"  />
			<input type="hidden" name="flag" id="flag" value="q"  />
			<table width="100%">
				<tr>
					<td><textarea name="dis_posts" class="input"  id="dis_posts_question" placeholder="Type Your Question" cols="52" rows="3"></textarea></td>
				</tr>
				<tr>
					<td>
						<select id="tags_question" name="tags">
						<option value="">Choose a Category</option>
						<option value="Customers">Customers</option>
						<option value="Employees">Employees</option>
						<option value="Products">Products</option>
						<option value="Moat">Moat</option>
						<option value="Pricing">Pricing</option>
						<option value="Market">Market</option>
						<option value="Competition">Competition</option>
						<option value="Plan">Plan</option>
						<option value="Priorities">Priorities</option>
						<option value="Metrics">Metrics</option>
						<option value="Financials">Financials</option>
						<option value="Risks">Risks</option>
						<option value="Opportunities">Opportunities</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<input type="submit" name="dis_post" value="Submit" onClick="return validate_questions()"  class="tool" /> 
						<input type="submit" name="dis_post" id="cancel" value="Cancel" onClick="javascript:$('#question').hide();return false;" class="tool" /></td>
				</tr>
				</table>
			</form>
			</div>
			
			<div style="clear:both"></div>
			</div>

	<?php
		$result = mysql_query("SELECT *,
			UNIX_TIMESTAMP() - date_created AS TimeSpent FROM pro_wall_posts where pro_id = ".$row1['id']." order by pid desc");
	while($row1 = mysql_fetch_array($result)) {
	
	$crId = nameToId($row1['user']);
	$uid = $crId;
	$uType = getUserType($crId);
	
	/*$result3 = mysql_query ("SELECT * 
							 FROM  `like_discussion_posts` 
							 WHERE  prof_id = '".$pro_id."' and post_id = '".$row1['pid']."' and user_id = '".$uid."'");*/
							 
	$result3 = mysql_query ("SELECT * 
							 FROM  `like_discussion_posts` 
							 WHERE  prof_id = '".$pro_id."' and post_id = '".$row1['pid']."'");
	$row3 = mysql_fetch_array($result3);
	$likepost1 = mysql_num_rows($result3);
	
	
	if ($uType == 'people' || $uType == 'admin') {
	
			//Get user gender
			$q1 = mysql_query("SELECT gender FROM maenna_people WHERE pid = ".$_REQUEST['id']."");
			$gender_tmp = mysql_fetch_array($q1);
			$gender = $gender_tmp['gender'];
	
	if (file_exists($base_url.'/sites/default/images/profiles/50x50/'.$crId.'.jpg')) { $avatar = $base_url.'/sites/default/images/profiles/50x50/'.$crId.'.jpg';} 
			  else {
					if ($gender == 'm' || $gender == '') { $avatar =$base_url.'/themes/maennaco/images/prof-avatar-male.png';}
	
						else $avatar = $base_url.'/themes/maennaco/images/prof-avatar-female.png';
				}
	}
	else if ($uType == 'company')  {
	
	//Get cmp_role		
			$q1 = mysql_query("SELECT company_type FROM maenna_company WHERE companyid = $crId") or die(mysql_error());
			$cmp_role_tmp = mysql_fetch_array($q1);
			$cmp_role = $cmp_role_tmp['company_type'];
			 //Check if user have a profile picture
			  if (file_exists($base_url.'/sites/default/images/company/50x50/'.$crId.'.jpg')) {$avatar = $base_url.'/sites/default/images/company/50x50/'.$crId.'.jpg';} 
			  else	
					if ($cmp_role == 'service') $avatar =$base_url.'/themes/maennaco/images/cmp-avatar-service.png';
					else $avatar =$base_url.'/themes/maennaco/images/cmp-avatar-product.png';
	
	}
	?>
			<div class="cmtloop" id="dis_post<?php echo $row1['pid'];?>">
            
            
			<div class="ask">
					<?php if($row1['flag'] != 'm') { ?>
					<div class="askpic">
					<?php echo "<img src=".$avatar." style=\"float:left; margin-top:13px; margin-right:5px; width:50px; height:50px;\">&nbsp;"; ?>
					</div>
					<?php if($row1['flag'] != 'm') { ?>
						<div class="asktitle"><?php echo $row1['f_name']; ?>&nbsp;<?php if($row1['flag'] == 'q') { echo '<strong>asks a question:</strong>';} ?></div>
						<?php } ?>
						
					<?php } ?>
 					<p style="margin:5px 0px 0px 0px;"><?=$row1['post']?> </p>
					<?php if($row1['flag'] != 'm') { $width ="525px"; }else { $width="592px";} ?>
					<div class="askright" style="width:<?php echo $width;?> !important; float: left; margin-left: 65px;">
						
						<!-- <?php if($row1['flag'] != 'q') { echo '<h5>' .  $row1['tags'] . '</h5>'; } ?></p> -->
						
						<div style="margin:0px 0px 5px 0px; padding:0px 0px 2px 0px;">
							<div style="height:30px; width: 535px;">
							<div class='comment_anchor' style="width:130px;float:left;margin-top:5px;">
							<?php
								if($likepost1 == 1) {
							?>
								<span style='margin:0px 0px 0px 0px;padding:0px 0px 0px 0px;' id="likepost1<?=$row1['pid']?>" ><a href="javascript:void(0);" style="cursor:pointer;" onClick="like_posts('unlike', '<?=$pro_id?>', '<?=$row1['pid']?>', '<?=$id?>');">Unlike</a></span>
								<?php } else {?>
								<span style='margin:0px 0px 0px 0px;padding:0px 0px 0px 0px;' id="likepost1<?=$row1['pid']?>" ><a href="javascript:void(0);" style="cursor:pointer;" onClick="like_posts('like', '<?=$pro_id?>', '<?=$row1['pid']?>', '<?=$id?>');">Like</a></span>
							<?php } ?>
							&nbsp;|&nbsp;<a onclick='formDisplay("<?=$row1['pid']?>");'>Comment</a>
							</div>
							<div style='float:right;margin:7px 0px 0px 0px;color:#76787f'>Topic: <?php echo $row1['tags'];?></div>
								 	<!--<a href="#">Invite</a>-->			
							</div>
							
						</div>
						<div style="clear:both"></div>
					 
	<?php
		$result2 = mysql_query("SELECT *,
			UNIX_TIMESTAMP() - datecreated AS TimeSpent FROM pro_wall_posts_comments where post_id=".$row1['pid']." order by cid asc");
	$comments_count = mysql_num_rows($result2);
	while($row2 = mysql_fetch_array($result2)) {
	?>
	<?php
	
	$crId = nameToId($row2['username']);
	$uType = getUserType($crId);
	
	
	if ($uType == 'people' || $uType == 'admin') {
	
			//Get user gender
			$q1 = mysql_query("SELECT gender FROM maenna_people WHERE pid = ".$_REQUEST['id']."");
			$gender_tmp = mysql_fetch_array($q1);
			$gender = $gender_tmp['gender'];
	
	if (file_exists($base_url.'/sites/default/images/profiles/50x50/'.$crId.'.jpg')) { $avatar = $base_url.'/sites/default/images/profiles/50x50/'.$crId.'.jpg';} 
			  else {
					if ($gender == 'm' || $gender == '') { $avatar =$base_url.'/themes/maennaco/images/prof-avatar-male.png';}
	
						else $avatar = $base_url.'/themes/maennaco/images/prof-avatar-female.png';
				}
	}
	else if ($uType == 'company')  {

	
	//Get cmp_role		
			$q1 = mysql_query("SELECT company_type FROM maenna_company WHERE companyid = $crId") or die(mysql_error());
			$cmp_role_tmp = mysql_fetch_array($q1);
			$cmp_role = $cmp_role_tmp['company_type'];

			 //Check if user have a profile picture
			  if (file_exists($base_url.'/sites/default/images/company/50x50/'.$crId.'.jpg')) {$avatar = $base_url.'/sites/default/images/company/50x50/'.$crId.'.jpg';} 
			  else	
					if ($cmp_role == 'service') $avatar =$base_url.'/themes/maennaco/images/cmp-avatar-service.png';
					else $avatar =$base_url.'/themes/maennaco/images/cmp-avatar-product.png';
	
	} 
	
	$comment_result = mysql_query ("SELECT * 
					     FROM  `like_discussion_posts_comments` 
					     WHERE  comment_id = '".$row2['cid']."' and user_id = '".$user->uid."'");

	$likepost_comment = mysql_num_rows($comment_result);
	?>
						 <div class="aucomnts">
						<div class="aucpic">
						<?php echo "<img src=".$avatar." style=\"float:left; margin-top:13px; margin-right:5px; width:45px; height:45px;\">&nbsp;"; ?>
						</div>
						<div class="aucdisc">
						<h5><?=$row2['username']?></h5>
						
						<p id="com<?php echo $row2['cid']; ?>"><?php echo $row2['comment']; ?></p>
						<div class='comment_anchor'>
						<div style='float:left;margin:0px;padding:0px;font-size:12px;'>
						<?=date("l, M j, Y g:i A T ",$row2['datecreated']);?>
						&nbsp;|&nbsp;
						</div>
						<div id='likepostcomment<?php echo $row2['cid'];?>' style='float:left;padding:0px 0px 0px 0px;'>
						<?php
							if($likepost_comment == 1) {
						?>
							<!-- <span id="likepost1<?=$row1['pid']?>" ><a href="javascript:void(0);" style="cursor:pointer;" onclick="like_posts('unlike', '<?=$pro_id?>', '<?=$row1['pid']?>', '<?=$id?>');">Unlike</a></span> -->
							<a href="javascript:void(0);" style="cursor:pointer;" onClick="like_post_comments('like',  '<?=$row2['cid']?>', '<?=$user->uid?>');">Unlike</a>
							<?php } else {?>
							<a href="javascript:void(0);" style="cursor:pointer;" onClick="like_post_comments('like',  '<?=$row2['cid']?>', '<?=$user->uid?>');">Like</a>
						<?php } ?>
						</div>
						<div style='float:left;'>
						<?php /*?><p>Tags : <?php echo $row1['tags']; ?></p><?php */?>
						<?php /*?><p><?php echo time() - $row1['date_created']; ?>&nbsp;few seconds ago<?php */?>  <?php
						 if($uid == $user->uid){?>
						<!-- <a style="cursor:pointer;" href="javascript:void(0);" id="deletepost<?=$row1['pid']?>" class="deletepost">Delete</a>-->
						  &nbsp;|&nbsp;<a style="cursor:pointer;" href="javascript:void(0);" id="delete_comment<?=$row2['cid']?>" class="delete_comment">Delete</a>
		 <?php } ?></p></div></div>
						</div><div style="clear:both"></div>	
						<!--<div class="aucpic"></div>
						<div class="aucdisc">
							<h5>Aseg Amin</h5>
						<p>Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like </p>
						</div><div style="clear:both"></div>--></div>
						
	<?php } 
	if($comments_count == 0)
	{
		$comment_style = "style='display:none;margin:21px 0px 0px 0px; padding:0px 0px 0px 20px; background:#f4f8fa!important;'";
	}
	else
	{
		$comment_style = "style='margin:21px 0px 0px 0px; padding:0px 0px 0px 20px; background:#f4f8fa!important;'";
	}
	?>  <div class="w" <?php echo $comment_style;?> id='form_id<?=$row1['pid']?>'>
								<form method="post" action="<?php echo $base_url; ?>/account?tab=professionals&page=pro_detail&id=<?php echo $id; ?>&section=pro_industry_view&type=details&pro_id=<?php echo $_REQUEST['pro_id']; ?>" id="comments">
									<input type="hidden" name="post_id" id="post_id" value="<?php echo $row1['pid']; ?>"  />
									<input type="hidden" name="dis_id" id="dis_id" value="<?php echo $_REQUEST['pro_id']; ?>"  />
									
									<?php
										if($row1['flag'] != 'm')
										{
											$marginleft = "83%";
											$width="97%";
										}else
										{
											$marginleft = "74%";
											$width="87%";
										}
									?>
									
									<textarea name="post_comment" id="post_comment<?php echo $row1['pid']; ?>" class=" input watermark" style="width:<?php echo $width; ?>;  margin: 5px 0px 0px -9px!important; height:25px; " onFocus="showsubmit('<?php echo $row1['pid']; ?>');"></textarea>
									
									<input type="submit" id="post_com<?php echo $row1['pid']; ?>" value="Submit" class="tool" style="display:none;vertical-align: top;margin-top: 0px;margin-left:<?php echo $marginleft; ?>;"  />
								</form>
								<!-- <textarea id="post_comments" style="width:85%; margin-left: 82px!important; margin-top: 10px!important;" ></textarea>-->
							</div>
					  
					</div>  
				</div>
                
                
                
		<div style="clear:both"></div>
		 
		 </div><br />
	<?php } ?>    
		</div>
<?php } ?>		
<!--- end conversation tab content -->

	 
        	</div>
</div>
<div id="createaccount" style="display:none">

<!--<form method="post" name="joinform" id="joinform">
First name: <input type="text" name="firstname" id="firstname" value=""  /><br />
Last name: <input type="text" name="lastname" id="lastname" value=""  /><br />
E-mail Address: <input type="text" name="emailid" id="emailid" value=""  /><br />
Password: <input type="password" name="password" id="password" value=""  /><br />
<input type="submit" name="submit" id="submit" value="SIGN UP"  /><br />
</form>-->
<form method="post" name="joinform" id="joinform">
<?php /*?>
First name: <input type="text" name="firstname" id="firstname" value=""  /><br />
Last name: <input type="text" name="lastname" id="lastname" value=""  /><br />
E-mail Address: <input type="text" name="emailid" id="emailid" value=""  /><br />
Password: <input type="password" name="password" id="password" value=""  /><br />
<input type="submit" name="submit" id="submit" value="SIGN UP"  /><br /><?php */?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" class="popup">
  <tr>
    <td>If you have an account, <a href="#">SIGN IN HERE</a></td>
  </tr>
  <tr>
    <td><table width="100%" border="0">
      <tr>
        <td class="poptit">First name:</td>
        <td class="poptit">Last Name</td>
      </tr>
      <tr>
        <td><input type="text" name="firstname" id="firstname" value=""  /></td>
        <td><input type="text" name="lastname" id="lastname" value=""  /></td>
      </tr>
    </table></td>
  </tr>
 
  <tr>

    <td class="poptit">E-mail Address:</td>
  </tr>
  <tr>
    <td><input type="text" name="emailid" id="emailid" value="" style="width:435px;" /></td>
  </tr>
  <tr>
    <td><table width="100%" border="0">
      <tr>
        <td class="poptit">Password</td>
        <td class="subtit">Minimum 5 Characters</td>
      </tr>
      <tr>
        <td colspan="2"><input type="text" name="firstname2" id="firstname2" value="" style="width:435px;" /></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><input type="submit" name="button" id="button" value="Submit" /></td>
  </tr>
</table>
</form>

</div>



    <script type="text/javascript">
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
$(".discussion_link").livequery("click",function (e) {				
	e.preventDefault();
	$( "#discussion_popup" ).dialog({
					autoOpen: true,
					width: 400,
					title: 'DISCUSSION TITLE',
					height:400,
					buttons: { 
		"Save":  function () { },
		"Cancel": function() { $(this).dialog("close"); }
	}, closeOnEscape: true,
	   modal:true
	}).show;	
});
</script>
<div id='discussion_popup' style='display:none;width:400px!important;'>
<form method='post' action=''>
<?=date("l, M j, Y g:i A T ",$row1['datetime']);?>
<p><?=$row1['description'];?></p>
Attending? 
<input type='radio' name='attending' id=''>YES
<input type='radio' name='attending' id=''>NO
<input type='radio' name='attending' id=''>MAY BE
</form>
</div>
<div id="payment" style="display:none">
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
    <td>To Join, Proceed with Payment</td>
  </tr>
  <tr>
    <td><table width="100%" border="0">
      <tr>
        <td class="poptit">COST:</td>
        <td class="poptit">$<?php echo $cost; ?></td>
      </tr>
      <tr>
        <td></td>
        <td>
	<!-- <form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post"> -->
	<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
    <input type="hidden" name="cmd" value="_xclick">
   <input type="hidden" name="business" value="clewed@clewed.com">
  <!-- <input type="hidden" name="business" value="test.business@gmail.com" /> -->
    <input type="hidden" name="item_name" value="<?php echo $P_username; ?>">
    <!--<input type="hidden" name="item_number" value="1">-->
    <input type="hidden" name="amount" value="<?php echo str_replace('$', '', $cost); ?>">
    <input type="hidden" name="no_shipping" value="0">
    <input type="hidden" name="no_note" value="1">
    <input type="hidden" name="currency_code" value="USD">
    <input type="hidden" name="lc" value="AU">
	<INPUT TYPE="hidden" NAME="return" value="<?php echo $paymenturl1;?>">
	<input type="hidden" name="custom_SauceColor">
    <input type="hidden" name="custom_HowHot">
    <!--<input type="hidden" name="bn" value="PP-BuyNowBF">-->
	<!--<input type="hidden" name="hosted_button_id" value="58JBKVTL2D9JW">-->
	<input type="hidden" name="hosted_button_id" value="58JBKVTL2D9JW">
	<!--<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">-->
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">

	<input type="hidden" name="rm" value="2">
   <!-- <input type="image" src="https://www.paypal.com/en_AU/i/btn/btn_buynow_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online.">-->
<div class="diss">
	<input type="submit" id="payment" class="small button" style="width: 212px !important;" value="PROCEED WITH PAYMENT">
</div>
	<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">   
	</form>
	</td>
      </tr>
    </table></td>
  </tr>
</table>

</div>