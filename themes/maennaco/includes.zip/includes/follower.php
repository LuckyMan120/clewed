<?php

	include('dbcon.php');
	
	if ($_REQUEST['type'] == 'setPublic') {

						if ($_REQUEST['target_publicity'] == 'public') $status = 1; else $status = 0;
						mysql_query("UPDATE maenna_people SET public = ".$status." WHERE pid = '".$_REQUEST['uid']."' ") or die(mysql_error());
					


					}
        elseif ($_REQUEST['type'] == 'unfollow') {

	mysql_query("DELETE FROM maenna_followers WHERE uid = '".$_REQUEST['pid']."' AND  cid = '".$_REQUEST['companyId']."' ") or die(mysql_error());

	echo "Unfollowing succeeded";

	}

	elseif ($_REQUEST['type'] == 'follow') {

	mysql_query("INSERT INTO maenna_followers (cid,uid) VALUES ('".$_REQUEST['companyId']."','".$_REQUEST['pid']."') ") or die(mysql_error());

	echo "You are now following this user.";

	}
?>